export interface Team {
  id: string;
  name: string;
  shortName: string;
  seed: number;
  record: string;
  conference: string;
  ppg: number;
  oppg: number;
  pace: number;
  eFGPct: number;
  tovPct: number;
  orebPct: number;
  sosRank: number;
  netRank: number;
  recentForm: ("W" | "L")[];
  color: string;
  rotobotScore: number;
  rotobotBlurb: string;
  keyPlayer: string;
  keyPlayerStat: string;
}

export interface Game {
  id: string;
  round: number;
  region: string;
  team1: Team;
  team2: Team;
  rotobotPick: string;
  rotobotConfidence: number;
  location: string;
  analysis: string;
  proTeam1: string[];
  proTeam2: string[];
  userPick?: string;
}

export const EAST_TEAMS: Team[] = [
  {
    id: "duke", name: "Duke Blue Devils", shortName: "Duke", seed: 1,
    record: "26-3", conference: "ACC", ppg: 83.4, oppg: 67.1, pace: 71.2,
    eFGPct: 56.8, tovPct: 14.1, orebPct: 32.1, sosRank: 4, netRank: 1,
    recentForm: ["W","W","W","W","L"], color: "#002F87",
    rotobotScore: 94, rotobotBlurb: "Elite offense and lockdown defense. Cooper Flagg is the tournament's best player.",
    keyPlayer: "Cooper Flagg", keyPlayerStat: "21.4 PPG / 8.2 RPG"
  },
  {
    id: "umbc", name: "UMBC Retrievers", shortName: "UMBC", seed: 16,
    record: "21-10", conference: "America East", ppg: 72.1, oppg: 68.4, pace: 64.1,
    eFGPct: 48.2, tovPct: 19.3, orebPct: 27.8, sosRank: 312, netRank: 187,
    recentForm: ["W","W","L","W","W"], color: "#000000",
    rotobotScore: 22, rotobotBlurb: "Conference auto-bid. History maker in 2018, but Duke is a different beast.",
    keyPlayer: "Devon Walker", keyPlayerStat: "17.8 PPG"
  },
  {
    id: "tennessee", name: "Tennessee Volunteers", shortName: "Tennessee", seed: 2,
    record: "24-5", conference: "SEC", ppg: 79.6, oppg: 64.2, pace: 67.8,
    eFGPct: 53.4, tovPct: 13.8, orebPct: 34.2, sosRank: 3, netRank: 3,
    recentForm: ["W","W","L","W","W"], color: "#FF8200",
    rotobotScore: 88, rotobotBlurb: "Rick Barnes' best team in years. Elite defense and dominant rebounding.",
    keyPlayer: "Zakai Zeigler", keyPlayerStat: "16.2 PPG / 5.8 APG"
  },
  {
    id: "samford", name: "Samford Bulldogs", shortName: "Samford", seed: 15,
    record: "23-8", conference: "SoCon", ppg: 75.3, oppg: 72.1, pace: 72.4,
    eFGPct: 50.1, tovPct: 18.2, orebPct: 28.4, sosRank: 298, netRank: 201,
    recentForm: ["W","L","W","W","W"], color: "#CC2244",
    rotobotScore: 28, rotobotBlurb: "Fun offensive team but will struggle against high-major defense.",
    keyPlayer: "A.J. Staton Jr.", keyPlayerStat: "19.3 PPG"
  },
  {
    id: "kansas", name: "Kansas Jayhawks", shortName: "Kansas", seed: 3,
    record: "23-6", conference: "Big 12", ppg: 80.2, oppg: 68.9, pace: 69.4,
    eFGPct: 54.1, tovPct: 14.9, orebPct: 31.8, sosRank: 8, netRank: 6,
    recentForm: ["W","L","W","W","W"], color: "#003087",
    rotobotScore: 84, rotobotBlurb: "Bill Self's system is tournament-tested. Deep frontcourt is a major advantage.",
    keyPlayer: "Hunter Dickinson", keyPlayerStat: "18.7 PPG / 9.4 RPG"
  },
  {
    id: "oakland", name: "Oakland Golden Grizzlies", shortName: "Oakland", seed: 14,
    record: "22-9", conference: "Horizon", ppg: 78.4, oppg: 75.6, pace: 76.8,
    eFGPct: 52.3, tovPct: 17.4, orebPct: 26.3, sosRank: 287, netRank: 189,
    recentForm: ["W","W","W","L","W"], color: "#FFB81C",
    rotobotScore: 31, rotobotBlurb: "High-scoring team but pace could hurt against disciplined Big 12 defense.",
    keyPlayer: "Trey Townsend", keyPlayerStat: "20.1 PPG"
  },
  {
    id: "ucla", name: "UCLA Bruins", shortName: "UCLA", seed: 4,
    record: "22-7", conference: "Big Ten", ppg: 77.8, oppg: 67.4, pace: 68.2,
    eFGPct: 52.8, tovPct: 15.2, orebPct: 30.4, sosRank: 11, netRank: 9,
    recentForm: ["W","W","W","L","W"], color: "#003B5C",
    rotobotScore: 81, rotobotBlurb: "Mick Cronin's defensive identity is back. Methodical offense with elite guard play.",
    keyPlayer: "Lazar Stefanovic", keyPlayerStat: "17.9 PPG / 4.2 APG"
  },
  {
    id: "vermont", name: "Vermont Catamounts", shortName: "Vermont", seed: 13,
    record: "24-7", conference: "America East", ppg: 71.2, oppg: 64.8, pace: 62.1,
    eFGPct: 53.4, tovPct: 15.8, orebPct: 25.2, sosRank: 290, netRank: 195,
    recentForm: ["W","W","W","W","L"], color: "#005A43",
    rotobotScore: 34, rotobotBlurb: "Jon Julius is a true sophomore stud. Vermont always overperforms expectations.",
    keyPlayer: "Tyler Gendron", keyPlayerStat: "16.8 PPG"
  },
  {
    id: "purdue", name: "Purdue Boilermakers", shortName: "Purdue", seed: 5,
    record: "21-8", conference: "Big Ten", ppg: 78.1, oppg: 70.2, pace: 66.4,
    eFGPct: 54.2, tovPct: 16.1, orebPct: 35.8, sosRank: 14, netRank: 12,
    recentForm: ["W","L","W","W","W"], color: "#CEB888",
    rotobotScore: 77, rotobotBlurb: "Post dominance is unmatched. Zach Edey 2.0 is emerging as an All-American.",
    keyPlayer: "Will Berg", keyPlayerStat: "16.4 PPG / 8.9 RPG"
  },
  {
    id: "uab", name: "UAB Blazers", shortName: "UAB", seed: 12,
    record: "24-8", conference: "American", ppg: 74.8, oppg: 70.1, pace: 70.2,
    eFGPct: 50.8, tovPct: 17.9, orebPct: 29.1, sosRank: 142, netRank: 98,
    recentForm: ["W","W","L","W","W"], color: "#1E6B52",
    rotobotScore: 47, rotobotBlurb: "5-12 upsets happen, and UAB has tournament DNA. Sneaky pick to watch.",
    keyPlayer: "Eric Gaines", keyPlayerStat: "15.2 PPG / 4.1 SPG"
  },
  {
    id: "creighton", name: "Creighton Bluejays", shortName: "Creighton", seed: 6,
    record: "22-7", conference: "Big East", ppg: 80.4, oppg: 71.8, pace: 70.8,
    eFGPct: 55.2, tovPct: 14.4, orebPct: 28.9, sosRank: 18, netRank: 14,
    recentForm: ["W","W","W","L","W"], color: "#005CA9",
    rotobotScore: 74, rotobotBlurb: "Ryan Kalkbrenner is unstoppable inside. Three-point barrage is a real threat.",
    keyPlayer: "Ryan Kalkbrenner", keyPlayerStat: "17.8 PPG / 8.2 RPG"
  },
  {
    id: "loyola-chicago", name: "Loyola Chicago Ramblers", shortName: "Loyola", seed: 11,
    record: "23-9", conference: "A-10", ppg: 70.4, oppg: 66.8, pace: 63.8,
    eFGPct: 49.8, tovPct: 16.2, orebPct: 30.8, sosRank: 188, netRank: 108,
    recentForm: ["W","L","W","W","W"], color: "#862633",
    rotobotScore: 42, rotobotBlurb: "Sister Jean is back. Defense-first team that upsets on low-possession games.",
    keyPlayer: "Drew Knapper", keyPlayerStat: "14.9 PPG"
  },
  {
    id: "texas-am", name: "Texas A&M Aggies", shortName: "Texas A&M", seed: 7,
    record: "20-9", conference: "SEC", ppg: 75.2, oppg: 69.4, pace: 67.1,
    eFGPct: 51.4, tovPct: 15.8, orebPct: 32.4, sosRank: 22, netRank: 18,
    recentForm: ["L","W","W","W","L"], color: "#500000",
    rotobotScore: 68, rotobotBlurb: "SEC battle-tested. Buzz Williams' defense can hang with anyone on a given night.",
    keyPlayer: "Tyrece Radford", keyPlayerStat: "15.8 PPG / 3.9 APG"
  },
  {
    id: "penn-state", name: "Penn State Nittany Lions", shortName: "Penn State", seed: 10,
    record: "21-10", conference: "Big Ten", ppg: 76.8, oppg: 72.1, pace: 69.8,
    eFGPct: 52.1, tovPct: 17.1, orebPct: 28.4, sosRank: 35, netRank: 41,
    recentForm: ["W","W","L","W","W"], color: "#003087",
    rotobotScore: 54, rotobotBlurb: "Aljami Durham's floor-spacing opens it up. Can go cold from three though.",
    keyPlayer: "Aljami Durham", keyPlayerStat: "17.1 PPG"
  },
  {
    id: "north-carolina", name: "UNC Tar Heels", shortName: "UNC", seed: 8,
    record: "20-9", conference: "ACC", ppg: 81.2, oppg: 74.8, pace: 74.2,
    eFGPct: 53.8, tovPct: 16.8, orebPct: 34.8, sosRank: 16, netRank: 21,
    recentForm: ["W","L","W","W","W"], color: "#4B9CD3",
    rotobotScore: 62, rotobotBlurb: "High-octane offense but defense is a concern. Hubert Davis' squad can go on runs.",
    keyPlayer: "Elliot Cadeau", keyPlayerStat: "15.4 PPG / 6.1 APG"
  },
  {
    id: "miss-state", name: "Mississippi State Bulldogs", shortName: "Miss State", seed: 9,
    record: "20-10", conference: "SEC", ppg: 74.1, oppg: 70.2, pace: 68.4,
    eFGPct: 50.2, tovPct: 18.1, orebPct: 31.2, sosRank: 28, netRank: 38,
    recentForm: ["W","L","W","L","W"], color: "#660000",
    rotobotScore: 59, rotobotBlurb: "Jon Cooper transfer has been huge. SEC physicality translates in the tournament.",
    keyPlayer: "Cameron Matthews", keyPlayerStat: "14.8 PPG / 6.2 RPG"
  },
];

export const WEST_TEAMS: Team[] = [
  {
    id: "auburn", name: "Auburn Tigers", shortName: "Auburn", seed: 1,
    record: "27-2", conference: "SEC", ppg: 84.1, oppg: 65.4, pace: 73.8,
    eFGPct: 57.4, tovPct: 13.4, orebPct: 33.8, sosRank: 2, netRank: 2,
    recentForm: ["W","W","W","W","W"], color: "#003087",
    rotobotScore: 96, rotobotBlurb: "The most complete team in the country. Johni Broome is a Naismith frontrunner.",
    keyPlayer: "Johni Broome", keyPlayerStat: "19.1 PPG / 10.8 RPG"
  },
  {
    id: "norfolk-state", name: "Norfolk State Spartans", shortName: "Norfolk St.", seed: 16,
    record: "22-10", conference: "MEAC", ppg: 71.4, oppg: 70.2, pace: 66.2,
    eFGPct: 47.8, tovPct: 19.8, orebPct: 28.1, sosRank: 342, netRank: 214,
    recentForm: ["W","W","W","L","W"], color: "#007041",
    rotobotScore: 18, rotobotBlurb: "MEAC champion with a nice guard trio but Auburn is historically dominant.",
    keyPlayer: "Christian Ings", keyPlayerStat: "18.4 PPG"
  },
  {
    id: "arizona", name: "Arizona Wildcats", shortName: "Arizona", seed: 2,
    record: "24-5", conference: "Pac-12+", ppg: 81.8, oppg: 69.1, pace: 72.4,
    eFGPct: 55.8, tovPct: 14.2, orebPct: 32.8, sosRank: 5, netRank: 4,
    recentForm: ["W","W","W","L","W"], color: "#003366",
    rotobotScore: 87, rotobotBlurb: "Tommy Lloyd's system produces March magic. KJ Lewis is electric off the bench.",
    keyPlayer: "KJ Lewis", keyPlayerStat: "18.2 PPG / 5.1 APG"
  },
  {
    id: "colgate", name: "Colgate Raiders", shortName: "Colgate", seed: 15,
    record: "24-7", conference: "Patriot", ppg: 73.4, oppg: 68.8, pace: 65.4,
    eFGPct: 51.2, tovPct: 17.2, orebPct: 26.4, sosRank: 278, netRank: 192,
    recentForm: ["W","L","W","W","W"], color: "#821019",
    rotobotScore: 26, rotobotBlurb: "Efficient but limited against elite athletes. Matt Langel's best team in years.",
    keyPlayer: "Tucker Richardson", keyPlayerStat: "16.2 PPG"
  },
  {
    id: "gonzaga", name: "Gonzaga Bulldogs", shortName: "Gonzaga", seed: 3,
    record: "24-5", conference: "WCC", ppg: 82.4, oppg: 70.2, pace: 71.8,
    eFGPct: 56.4, tovPct: 14.8, orebPct: 31.4, sosRank: 31, netRank: 7,
    recentForm: ["W","W","W","W","L"], color: "#002469",
    rotobotScore: 83, rotobotBlurb: "Few has rebuilt beautifully. Braden Huff is an All-American big man.",
    keyPlayer: "Braden Huff", keyPlayerStat: "17.8 PPG / 7.4 RPG"
  },
  {
    id: "grand-canyon", name: "Grand Canyon Antelopes", shortName: "GCU", seed: 14,
    record: "25-6", conference: "WAC", ppg: 74.2, oppg: 69.8, pace: 67.4,
    eFGPct: 51.8, tovPct: 16.8, orebPct: 29.2, sosRank: 194, netRank: 121,
    recentForm: ["W","W","W","W","L"], color: "#522398",
    rotobotScore: 33, rotobotBlurb: "GCU always plays spoiler. Jovan Blacksher Jr. can erupt for 30 at any time.",
    keyPlayer: "Jovan Blacksher Jr.", keyPlayerStat: "19.8 PPG"
  },
  {
    id: "iowa-state", name: "Iowa State Cyclones", shortName: "Iowa St.", seed: 4,
    record: "22-7", conference: "Big 12", ppg: 76.8, oppg: 66.8, pace: 67.2,
    eFGPct: 52.4, tovPct: 14.1, orebPct: 31.2, sosRank: 9, netRank: 10,
    recentForm: ["W","W","W","W","L"], color: "#C8102E",
    rotobotScore: 80, rotobotBlurb: "T.J. Otzelberger's defense is tournament-proof. Deep roster with no weak spots.",
    keyPlayer: "Milan Momcilovic", keyPlayerStat: "16.1 PPG / 4.8 APG"
  },
  {
    id: "yale", name: "Yale Bulldogs", shortName: "Yale", seed: 13,
    record: "23-6", conference: "Ivy", ppg: 76.4, oppg: 72.8, pace: 68.4,
    eFGPct: 54.2, tovPct: 15.4, orebPct: 24.8, sosRank: 241, netRank: 144,
    recentForm: ["W","W","W","L","W"], color: "#00356B",
    rotobotScore: 36, rotobotBlurb: "Highly efficient offense with great three-point shooting. Smart basketball team.",
    keyPlayer: "John Poulakidas", keyPlayerStat: "16.8 PPG"
  },
  {
    id: "michigan-state", name: "Michigan State Spartans", shortName: "Michigan St.", seed: 5,
    record: "20-9", conference: "Big Ten", ppg: 76.2, oppg: 68.4, pace: 66.8,
    eFGPct: 52.1, tovPct: 15.8, orebPct: 33.4, sosRank: 12, netRank: 15,
    recentForm: ["W","W","L","W","W"], color: "#18453B",
    rotobotScore: 76, rotobotBlurb: "Tom Izzo's tournament pedigree can't be overstated. Physical and experienced.",
    keyPlayer: "Coen Carr", keyPlayerStat: "15.4 PPG / 6.1 RPG"
  },
  {
    id: "james-madison", name: "James Madison Dukes", shortName: "JMU", seed: 12,
    record: "24-8", conference: "Sun Belt", ppg: 77.8, oppg: 72.4, pace: 74.2,
    eFGPct: 52.8, tovPct: 17.2, orebPct: 28.4, sosRank: 198, netRank: 112,
    recentForm: ["W","W","W","W","L"], color: "#450084",
    rotobotScore: 46, rotobotBlurb: "12-seeds are classic upset picks. JMU's guard play can frustrate Michigan State.",
    keyPlayer: "Terrence Edwards Jr.", keyPlayerStat: "19.2 PPG"
  },
  {
    id: "st-johns", name: "St. John's Red Storm", shortName: "St. John's", seed: 6,
    record: "23-6", conference: "Big East", ppg: 78.4, oppg: 70.1, pace: 71.4,
    eFGPct: 53.8, tovPct: 15.2, orebPct: 30.8, sosRank: 20, netRank: 16,
    recentForm: ["W","W","W","W","W"], color: "#CC0000",
    rotobotScore: 73, rotobotBlurb: "Rick Pitino has revived the brand. RJ Luis Jr. is a lottery pick getting better.",
    keyPlayer: "RJ Luis Jr.", keyPlayerStat: "18.8 PPG / 7.2 RPG"
  },
  {
    id: "texas", name: "Texas Longhorns", shortName: "Texas", seed: 11,
    record: "21-9", conference: "SEC", ppg: 74.8, oppg: 70.8, pace: 68.4,
    eFGPct: 51.2, tovPct: 16.4, orebPct: 30.2, sosRank: 24, netRank: 29,
    recentForm: ["W","L","L","W","W"], color: "#BF5700",
    rotobotScore: 44, rotobotBlurb: "Texas under Beard 2.0 is physical and disruptive. Volatile but talented.",
    keyPlayer: "Tre Johnson", keyPlayerStat: "18.2 PPG"
  },
  {
    id: "clemson", name: "Clemson Tigers", shortName: "Clemson", seed: 7,
    record: "21-8", conference: "ACC", ppg: 73.4, oppg: 67.1, pace: 65.8,
    eFGPct: 51.4, tovPct: 14.8, orebPct: 29.8, sosRank: 19, netRank: 22,
    recentForm: ["W","W","W","L","W"], color: "#F56600",
    rotobotScore: 67, rotobotBlurb: "Brad Brownell's steady hand. Elite defensive team, limited offensively at times.",
    keyPlayer: "Chase Hunter", keyPlayerStat: "14.8 PPG / 3.8 APG"
  },
  {
    id: "xavier", name: "Xavier Musketeers", shortName: "Xavier", seed: 10,
    record: "20-10", conference: "Big East", ppg: 76.2, oppg: 72.4, pace: 70.2,
    eFGPct: 52.4, tovPct: 17.8, orebPct: 28.2, sosRank: 42, netRank: 47,
    recentForm: ["W","L","W","W","L"], color: "#9E1B32",
    rotobotScore: 52, rotobotBlurb: "Inconsistent year but huge upside on a good shooting night.",
    keyPlayer: "Dayvion McKnight", keyPlayerStat: "16.4 PPG"
  },
  {
    id: "baylor", name: "Baylor Bears", shortName: "Baylor", seed: 8,
    record: "20-9", conference: "Big 12", ppg: 79.2, oppg: 72.8, pace: 72.4,
    eFGPct: 54.2, tovPct: 16.8, orebPct: 31.8, sosRank: 15, netRank: 24,
    recentForm: ["W","W","L","W","W"], color: "#003015",
    rotobotScore: 64, rotobotBlurb: "Scott Drew's NBA-style offense is dangerous. Guard depth is a real asset.",
    keyPlayer: "VJ Edgecombe", keyPlayerStat: "17.4 PPG / 4.8 APG"
  },
  {
    id: "oklahoma", name: "Oklahoma Sooners", shortName: "Oklahoma", seed: 9,
    record: "20-11", conference: "SEC", ppg: 77.4, oppg: 74.1, pace: 71.8,
    eFGPct: 52.8, tovPct: 17.4, orebPct: 30.4, sosRank: 26, netRank: 36,
    recentForm: ["L","W","W","L","W"], color: "#841617",
    rotobotScore: 57, rotobotBlurb: "Porter Moser's best recruiting class is paying off. Frontcourt advantage over Baylor.",
    keyPlayer: "Javian McCollum", keyPlayerStat: "16.8 PPG"
  },
];

export const SOUTH_TEAMS: Team[] = [
  {
    id: "houston", name: "Houston Cougars", shortName: "Houston", seed: 1,
    record: "25-4", conference: "Big 12", ppg: 77.4, oppg: 62.8, pace: 65.2,
    eFGPct: 53.1, tovPct: 12.8, orebPct: 35.4, sosRank: 6, netRank: 5,
    recentForm: ["W","W","W","L","W"], color: "#C8102E",
    rotobotScore: 91, rotobotBlurb: "Kelvin Sampson's machine. The grittiest team in the country. Defense wins championships.",
    keyPlayer: "Milos Uzan", keyPlayerStat: "15.8 PPG / 7.2 APG"
  },
  {
    id: "siu", name: "SIU Edwardsville Cougars", shortName: "SIUE", seed: 16,
    record: "19-12", conference: "MEAC", ppg: 68.4, oppg: 70.1, pace: 63.4,
    eFGPct: 45.8, tovPct: 20.4, orebPct: 26.8, sosRank: 358, netRank: 298,
    recentForm: ["W","L","W","W","L"], color: "#CC3333",
    rotobotScore: 14, rotobotBlurb: "Just happy to be here. A historical upset would shake college basketball.",
    keyPlayer: "Lamar Wright", keyPlayerStat: "14.2 PPG"
  },
  {
    id: "kentucky", name: "Kentucky Wildcats", shortName: "Kentucky", seed: 2,
    record: "23-6", conference: "SEC", ppg: 81.2, oppg: 69.4, pace: 72.1,
    eFGPct: 54.8, tovPct: 14.4, orebPct: 33.2, sosRank: 7, netRank: 8,
    recentForm: ["W","W","W","W","L"], color: "#005DAA",
    rotobotScore: 86, rotobotBlurb: "Mark Pope's first full recruiting class is loaded. Aerial Powers Jr. is a superstar.",
    keyPlayer: "Aerial Powers Jr.", keyPlayerStat: "20.4 PPG"
  },
  {
    id: "stetson", name: "Stetson Hatters", shortName: "Stetson", seed: 15,
    record: "22-11", conference: "ASUN", ppg: 74.2, oppg: 71.4, pace: 69.8,
    eFGPct: 49.8, tovPct: 18.8, orebPct: 27.2, sosRank: 280, netRank: 208,
    recentForm: ["W","W","L","W","W"], color: "#006747",
    rotobotScore: 24, rotobotBlurb: "Scrappy ASUN squad. First-round exit expected against elite SEC competition.",
    keyPlayer: "Stephan Swenson", keyPlayerStat: "17.4 PPG"
  },
  {
    id: "illinois", name: "Illinois Fighting Illini", shortName: "Illinois", seed: 3,
    record: "23-6", conference: "Big Ten", ppg: 79.8, oppg: 68.2, pace: 69.8,
    eFGPct: 54.4, tovPct: 14.2, orebPct: 32.8, sosRank: 10, netRank: 11,
    recentForm: ["W","W","L","W","W"], color: "#E84A27",
    rotobotScore: 85, rotobotBlurb: "Brad Underwood's best team ever. Coleman Hawkins is a two-way nightmare.",
    keyPlayer: "Coleman Hawkins", keyPlayerStat: "16.8 PPG / 7.8 RPG"
  },
  {
    id: "morehead-state", name: "Morehead State Eagles", shortName: "Morehead St.", seed: 14,
    record: "23-8", conference: "OVC", ppg: 76.8, oppg: 72.1, pace: 72.8,
    eFGPct: 52.1, tovPct: 17.8, orebPct: 28.4, sosRank: 292, netRank: 196,
    recentForm: ["W","W","W","W","L"], color: "#003087",
    rotobotScore: 29, rotobotBlurb: "Surprise OVC winner with high-energy offense. Match-up nightmare potential is low.",
    keyPlayer: "Riley Minix", keyPlayerStat: "18.8 PPG"
  },
  {
    id: "wisconsin", name: "Wisconsin Badgers", shortName: "Wisconsin", seed: 4,
    record: "22-7", conference: "Big Ten", ppg: 73.4, oppg: 65.8, pace: 62.4,
    eFGPct: 54.8, tovPct: 12.8, orebPct: 29.8, sosRank: 13, netRank: 13,
    recentForm: ["W","W","W","W","W"], color: "#C5050C",
    rotobotScore: 79, rotobotBlurb: "Methodical and impossible to beat in a low-possession game. AJ Storr is an assassin.",
    keyPlayer: "AJ Storr", keyPlayerStat: "17.2 PPG"
  },
  {
    id: "high-point", name: "High Point Panthers", shortName: "High Point", seed: 13,
    record: "25-7", conference: "Big South", ppg: 78.4, oppg: 73.2, pace: 74.4,
    eFGPct: 53.2, tovPct: 17.4, orebPct: 27.8, sosRank: 262, netRank: 178,
    recentForm: ["W","W","W","L","W"], color: "#440099",
    rotobotScore: 32, rotobotBlurb: "Fast-paced and fun but pace will be neutralized by Wisconsin's control game.",
    keyPlayer: "Zane Meeks", keyPlayerStat: "20.2 PPG"
  },
  {
    id: "oregon", name: "Oregon Ducks", shortName: "Oregon", seed: 5,
    record: "21-8", conference: "Big Ten", ppg: 77.2, oppg: 71.4, pace: 70.4,
    eFGPct: 52.8, tovPct: 16.2, orebPct: 30.4, sosRank: 17, netRank: 20,
    recentForm: ["W","L","W","W","W"], color: "#007030",
    rotobotScore: 75, rotobotBlurb: "Dana Altman reloads as always. N'Faly Dante is a legitimate center of the year candidate.",
    keyPlayer: "N'Faly Dante", keyPlayerStat: "16.2 PPG / 8.8 RPG"
  },
  {
    id: "colorado", name: "Colorado Buffaloes", shortName: "Colorado", seed: 12,
    record: "22-9", conference: "Big 12", ppg: 76.4, oppg: 72.8, pace: 71.2,
    eFGPct: 51.8, tovPct: 17.8, orebPct: 28.2, sosRank: 48, netRank: 62,
    recentForm: ["W","W","L","W","W"], color: "#CFB87C",
    rotobotScore: 45, rotobotBlurb: "Big 12 battle-tested sleeper. KJ Simpson is healthy and that changes everything.",
    keyPlayer: "KJ Simpson", keyPlayerStat: "18.4 PPG / 5.2 APG"
  },
  {
    id: "missouri", name: "Missouri Tigers", shortName: "Missouri", seed: 6,
    record: "21-8", conference: "SEC", ppg: 78.8, oppg: 72.1, pace: 71.8,
    eFGPct: 53.4, tovPct: 15.8, orebPct: 31.4, sosRank: 21, netRank: 19,
    recentForm: ["W","W","W","W","L"], color: "#F1B82D",
    rotobotScore: 72, rotobotBlurb: "Dennis Gates has transformed the program. Caleb Grill's shooting is a weapon.",
    keyPlayer: "Caleb Grill", keyPlayerStat: "16.2 PPG"
  },
  {
    id: "georgia", name: "Georgia Bulldogs", shortName: "Georgia", seed: 11,
    record: "20-10", conference: "SEC", ppg: 75.4, oppg: 71.8, pace: 70.4,
    eFGPct: 51.4, tovPct: 17.4, orebPct: 30.8, sosRank: 32, netRank: 44,
    recentForm: ["W","L","W","W","W"], color: "#BA0C2F",
    rotobotScore: 43, rotobotBlurb: "SEC road wins matter. Physical and underrated backcourt might be Georgia's ticket.",
    keyPlayer: "RJ Godfrey", keyPlayerStat: "15.8 PPG"
  },
  {
    id: "michigan", name: "Michigan Wolverines", shortName: "Michigan", seed: 7,
    record: "20-9", conference: "Big Ten", ppg: 76.8, oppg: 70.8, pace: 68.8,
    eFGPct: 52.2, tovPct: 16.8, orebPct: 30.2, sosRank: 23, netRank: 25,
    recentForm: ["W","W","L","W","W"], color: "#00274C",
    rotobotScore: 66, rotobotBlurb: "Dusty May's first big year. Nimari Burnett is a legitimate first-rounder.",
    keyPlayer: "Nimari Burnett", keyPlayerStat: "17.4 PPG"
  },
  {
    id: "new-mexico", name: "New Mexico Lobos", shortName: "New Mexico", seed: 10,
    record: "23-8", conference: "MWC", ppg: 78.2, oppg: 73.4, pace: 73.4,
    eFGPct: 53.2, tovPct: 17.2, orebPct: 29.8, sosRank: 88, netRank: 71,
    recentForm: ["W","W","W","L","W"], color: "#BA0C2F",
    rotobotScore: 51, rotobotBlurb: "Jaelen House is electric. Altitude advantage gone at neutral sites.",
    keyPlayer: "Jaelen House", keyPlayerStat: "18.8 PPG / 5.1 APG"
  },
  {
    id: "dayton", name: "Dayton Flyers", shortName: "Dayton", seed: 8,
    record: "22-7", conference: "A-10", ppg: 78.4, oppg: 70.4, pace: 70.8,
    eFGPct: 54.2, tovPct: 15.8, orebPct: 30.4, sosRank: 54, netRank: 34,
    recentForm: ["W","W","W","L","W"], color: "#004B8D",
    rotobotScore: 63, rotobotBlurb: "Anthony Grant's beautiful offensive system. Toumani Camara 2.0 has arrived.",
    keyPlayer: "DaRon Holmes II", keyPlayerStat: "18.1 PPG / 8.4 RPG"
  },
  {
    id: "indiana", name: "Indiana Hoosiers", shortName: "Indiana", seed: 9,
    record: "20-10", conference: "Big Ten", ppg: 76.2, oppg: 72.8, pace: 71.4,
    eFGPct: 52.4, tovPct: 17.8, orebPct: 31.4, sosRank: 30, netRank: 42,
    recentForm: ["L","W","W","W","L"], color: "#990000",
    rotobotScore: 58, rotobotBlurb: "Mike Woodson's squad is streaky. When IU is locked in, they beat anyone.",
    keyPlayer: "Mackenzie Mgbako", keyPlayerStat: "16.8 PPG"
  },
];

export const MIDWEST_TEAMS: Team[] = [
  {
    id: "florida", name: "Florida Gators", shortName: "Florida", seed: 1,
    record: "25-4", conference: "SEC", ppg: 82.8, oppg: 66.2, pace: 72.8,
    eFGPct: 56.2, tovPct: 13.2, orebPct: 34.2, sosRank: 8, netRank: 3,
    recentForm: ["W","W","W","W","W"], color: "#0021A5",
    rotobotScore: 93, rotobotBlurb: "Todd Golden's meteoric rise continues. Walter Clayton Jr. is the country's best PG.",
    keyPlayer: "Walter Clayton Jr.", keyPlayerStat: "18.8 PPG / 5.8 APG"
  },
  {
    id: "unc-asheville", name: "UNC Asheville Bulldogs", shortName: "UNC Asheville", seed: 16,
    record: "20-11", conference: "Big South", ppg: 71.8, oppg: 70.4, pace: 67.8,
    eFGPct: 48.8, tovPct: 20.1, orebPct: 27.4, sosRank: 320, netRank: 222,
    recentForm: ["W","L","W","W","W"], color: "#005CB9",
    rotobotScore: 16, rotobotBlurb: "Big South champion, outmatched at every position against a national powerhouse.",
    keyPlayer: "Drew Pember", keyPlayerStat: "19.4 PPG"
  },
  {
    id: "alabama", name: "Alabama Crimson Tide", shortName: "Alabama", seed: 2,
    record: "24-5", conference: "SEC", ppg: 83.4, oppg: 70.8, pace: 76.2,
    eFGPct: 56.8, tovPct: 15.2, orebPct: 32.4, sosRank: 5, netRank: 6,
    recentForm: ["W","W","L","W","W"], color: "#9E1B32",
    rotobotScore: 89, rotobotBlurb: "Nate Oats' system is on full display. Explosive offense with seven players who can go off.",
    keyPlayer: "Mark Sears", keyPlayerStat: "20.8 PPG / 5.4 APG"
  },
  {
    id: "robert-morris", name: "Robert Morris Colonials", shortName: "Robert Morris", seed: 15,
    record: "21-10", conference: "Horizon", ppg: 72.8, oppg: 70.2, pace: 68.4,
    eFGPct: 49.4, tovPct: 19.2, orebPct: 27.8, sosRank: 298, netRank: 212,
    recentForm: ["W","W","W","L","W"], color: "#005CB9",
    rotobotScore: 20, rotobotBlurb: "Gutsy Horizon champs. Alabama's scoring depth is simply too much to handle.",
    keyPlayer: "Amarion Dickerson", keyPlayerStat: "17.8 PPG"
  },
  {
    id: "texas-tech", name: "Texas Tech Red Raiders", shortName: "Texas Tech", seed: 3,
    record: "23-6", conference: "Big 12", ppg: 76.4, oppg: 64.8, pace: 64.8,
    eFGPct: 52.8, tovPct: 13.4, orebPct: 33.8, sosRank: 6, netRank: 9,
    recentForm: ["W","W","W","W","L"], color: "#CC0000",
    rotobotScore: 82, rotobotBlurb: "Grant McCasland has the Red Raiders defense at Bob Knight-level. Grinding style wins.",
    keyPlayer: "Darrion Williams", keyPlayerStat: "15.8 PPG / 6.4 RPG"
  },
  {
    id: "georgia-state", name: "Georgia State Panthers", shortName: "Georgia St.", seed: 14,
    record: "22-9", conference: "Sun Belt", ppg: 74.4, oppg: 71.2, pace: 72.2,
    eFGPct: 51.4, tovPct: 18.4, orebPct: 28.8, sosRank: 272, netRank: 188,
    recentForm: ["W","W","L","W","W"], color: "#0039A6",
    rotobotScore: 27, rotobotBlurb: "Sun Belt program that competes hard but faces a massive talent gap.",
    keyPlayer: "Darian Adams", keyPlayerStat: "16.8 PPG"
  },
  {
    id: "marquette", name: "Marquette Golden Eagles", shortName: "Marquette", seed: 4,
    record: "23-6", conference: "Big East", ppg: 80.4, oppg: 68.2, pace: 70.8,
    eFGPct: 55.4, tovPct: 14.8, orebPct: 32.4, sosRank: 16, netRank: 12,
    recentForm: ["W","W","W","L","W"], color: "#003366",
    rotobotScore: 78, rotobotBlurb: "Shaka Smart has Marquette playing its best basketball in a decade.",
    keyPlayer: "Oso Ighodaro", keyPlayerStat: "14.8 PPG / 8.4 RPG"
  },
  {
    id: "cleveland-state", name: "Cleveland State Vikings", shortName: "Cleveland St.", seed: 13,
    record: "23-8", conference: "Horizon", ppg: 73.8, oppg: 70.4, pace: 69.4,
    eFGPct: 51.2, tovPct: 17.8, orebPct: 28.2, sosRank: 288, netRank: 199,
    recentForm: ["W","W","W","W","L"], color: "#006747",
    rotobotScore: 30, rotobotBlurb: "Horizon league success is a nice story but Big East physicality is a different world.",
    keyPlayer: "Tre Gomillion", keyPlayerStat: "17.4 PPG"
  },
  {
    id: "connecticut", name: "UConn Huskies", shortName: "UConn", seed: 5,
    record: "22-7", conference: "Big East", ppg: 78.8, oppg: 67.4, pace: 68.8,
    eFGPct: 54.2, tovPct: 13.8, orebPct: 32.8, sosRank: 18, netRank: 17,
    recentForm: ["W","W","W","W","L"], color: "#000E2F",
    rotobotScore: 78, rotobotBlurb: "Three-peat window is open. Donovan Clingan's replacement has stepped up big.",
    keyPlayer: "Samson Johnson", keyPlayerStat: "14.4 PPG / 8.8 RPG"
  },
  {
    id: "mcneese-state", name: "McNeese State Cowboys", shortName: "McNeese St.", seed: 12,
    record: "25-7", conference: "Southland", ppg: 77.8, oppg: 72.4, pace: 74.8,
    eFGPct: 53.2, tovPct: 17.4, orebPct: 28.8, sosRank: 211, netRank: 134,
    recentForm: ["W","W","W","W","W"], color: "#0067A0",
    rotobotScore: 44, rotobotBlurb: "Southland powerhouse on a hot streak. Tre Mitchell's veteran leadership is key.",
    keyPlayer: "Christian Shumate", keyPlayerStat: "18.4 PPG"
  },
  {
    id: "byu", name: "BYU Cougars", shortName: "BYU", seed: 6,
    record: "22-7", conference: "Big 12", ppg: 79.2, oppg: 72.8, pace: 71.4,
    eFGPct: 54.8, tovPct: 15.4, orebPct: 30.8, sosRank: 22, netRank: 20,
    recentForm: ["W","W","W","L","W"], color: "#005DAA",
    rotobotScore: 71, rotobotBlurb: "Kevin Young is a coaching revelation. Trey Stewart is the most underrated player in the Big 12.",
    keyPlayer: "Trey Stewart", keyPlayerStat: "17.8 PPG / 4.8 APG"
  },
  {
    id: "nebraska", name: "Nebraska Cornhuskers", shortName: "Nebraska", seed: 11,
    record: "20-11", conference: "Big Ten", ppg: 75.4, oppg: 72.1, pace: 70.8,
    eFGPct: 52.1, tovPct: 17.1, orebPct: 29.4, sosRank: 28, netRank: 38,
    recentForm: ["W","W","L","W","W"], color: "#E41C38",
    rotobotScore: 45, rotobotBlurb: "Fred Hoiberg's squad finally has depth. Big Ten battle-tested and peaking at right time.",
    keyPlayer: "Juwan Gary", keyPlayerStat: "16.4 PPG"
  },
  {
    id: "memphis", name: "Memphis Tigers", shortName: "Memphis", seed: 7,
    record: "21-8", conference: "American", ppg: 80.2, oppg: 74.8, pace: 74.8,
    eFGPct: 53.8, tovPct: 17.8, orebPct: 33.4, sosRank: 44, netRank: 31,
    recentForm: ["W","W","W","W","L"], color: "#003087",
    rotobotScore: 65, rotobotBlurb: "Penny Hardaway's recruiting pays dividends. Athletic and explosive but turnover-prone.",
    keyPlayer: "Kalu Odu", keyPlayerStat: "17.8 PPG"
  },
  {
    id: "vanderbilt", name: "Vanderbilt Commodores", shortName: "Vanderbilt", seed: 10,
    record: "20-11", conference: "SEC", ppg: 77.8, oppg: 74.2, pace: 72.8,
    eFGPct: 53.4, tovPct: 17.2, orebPct: 29.8, sosRank: 34, netRank: 48,
    recentForm: ["W","L","W","W","W"], color: "#866D4B",
    rotobotScore: 50, rotobotBlurb: "Jerry Stackhouse's best team. SEC gauntlet has toughened them up.",
    keyPlayer: "Jason Edwards", keyPlayerStat: "17.2 PPG"
  },
  {
    id: "pittsburgh", name: "Pittsburgh Panthers", shortName: "Pittsburgh", seed: 8,
    record: "20-9", conference: "ACC", ppg: 77.4, oppg: 71.4, pace: 70.8,
    eFGPct: 53.2, tovPct: 16.4, orebPct: 31.2, sosRank: 24, netRank: 27,
    recentForm: ["W","W","L","W","W"], color: "#003594",
    rotobotScore: 61, rotobotBlurb: "Jeff Capel's best Pittsburgh team in years. Blake Hinson is back to his Iowa State form.",
    keyPlayer: "Ishmael Leggett", keyPlayerStat: "16.8 PPG"
  },
  {
    id: "ole-miss", name: "Ole Miss Rebels", shortName: "Ole Miss", seed: 9,
    record: "20-10", conference: "SEC", ppg: 76.8, oppg: 73.4, pace: 71.8,
    eFGPct: 52.8, tovPct: 17.8, orebPct: 30.8, sosRank: 27, netRank: 39,
    recentForm: ["W","L","W","W","W"], color: "#CE1126",
    rotobotScore: 56, rotobotBlurb: "Chris Beard has Ole Miss competing at the highest SEC level. Deep, versatile roster.",
    keyPlayer: "Matthew Murrell", keyPlayerStat: "17.4 PPG"
  },
];

// First round games (Round 1 - R64)
export const EAST_R1_GAMES: Game[] = [
  {
    id: "east-r1-1", round: 1, region: "East",
    team1: EAST_TEAMS[0], team2: EAST_TEAMS[1], // 1 vs 16
    rotobotPick: "duke", rotobotConfidence: 97,
    location: "Columbus, OH",
    analysis: "Duke's talent advantage is overwhelming at every position. Cooper Flagg is operating at a level rarely seen in March Madness. UMBC's 2018 magic was a 1-in-1000 event and Duke's defensive preparation leaves no room for miracles.",
    proTeam1: ["Cooper Flagg is the projected #1 overall pick", "Elite defensive efficiency (#2 nationally)", "Experience in high-pressure situations", "Superior depth at all five positions"],
    proTeam2: ["Historically upset-capable program", "Guard trio creates chaos", "Low-turnover offense can slow pace", "Nothing to lose mentality"]
  },
  {
    id: "east-r1-2", round: 1, region: "East",
    team1: EAST_TEAMS[2], team2: EAST_TEAMS[3], // 2 vs 15
    rotobotPick: "tennessee", rotobotConfidence: 91,
    location: "Columbus, OH",
    analysis: "Tennessee's defensive identity is built for March. Rick Barnes' teams always show up in the tournament and this squad has the tools to make a run. Samford's offensive efficiency will be neutralized by the Vols' suffocating pressure.",
    proTeam1: ["Elite defense (#1 opponent eFG% in SEC)", "Battle-tested SEC schedule", "Zakai Zeigler is a tournament-caliber leader", "Superior rebounding margin"],
    proTeam2: ["Experienced rotation with 8 contributors", "Efficient offense on good shooting nights", "Coach A.J. Staton Jr. capable of a hot streak", "Nothing to lose in first round"]
  },
  {
    id: "east-r1-3", round: 1, region: "East",
    team1: EAST_TEAMS[4], team2: EAST_TEAMS[5], // 3 vs 14
    rotobotPick: "kansas", rotobotConfidence: 88,
    location: "Charlotte, NC",
    analysis: "Kansas is the most experienced team in the field. Hunter Dickinson's size advantage creates unstoppable paint scoring that Oakland cannot contain. Bill Self's tournament experience gives Kansas a significant edge in close moments.",
    proTeam1: ["Hunter Dickinson is unstoppable in the post", "10 players log meaningful minutes", "Bill Self's 8 Final Four appearances", "Best free throw defense in the Big 12"],
    proTeam2: ["High-pace offense pressures every team", "Trey Townsend is an elite scorer", "No pressure means freedom to shoot", "Oakland nearly upsets Big Ten teams in tune-up games"]
  },
  {
    id: "east-r1-4", round: 1, region: "East",
    team1: EAST_TEAMS[6], team2: EAST_TEAMS[7], // 4 vs 13
    rotobotPick: "ucla", rotobotConfidence: 74,
    location: "Charlotte, NC",
    analysis: "UCLA's defense is one of the best in the country and will frustrate Vermont's methodical offense. However, Vermont's low-turnover approach and Jon Julius' emergence make this a sneaky upset candidate. 4-13 upsets happen 21% of the time historically.",
    proTeam1: ["Elite defensive system under Cronin", "Size advantage at every frontcourt position", "Big Ten experience prepares for physical games", "Deep and versatile roster"],
    proTeam2: ["Low-turnover, high-efficiency offense (13.1% TOV rate)", "Jon Julius is a legitimate NBA prospect", "Vermont wins against spread-out defenses", "Familiarity with low-seed pressure situations"]
  },
  {
    id: "east-r1-5", round: 1, region: "East",
    team1: EAST_TEAMS[8], team2: EAST_TEAMS[9], // 5 vs 12
    rotobotPick: "purdue", rotobotConfidence: 68,
    location: "Indianapolis, IN",
    analysis: "5-12 matchups are notoriously competitive (35% upset rate). Purdue's post dominance is hard to deal with but UAB's length and activity can disrupt. RotoBot gives UAB a legitimate 32% win probability — this is a game to watch.",
    proTeam1: ["Post dominance creates 3+ point swings per possession", "Will Berg is developing into a Terhune-tier center", "Big Ten battle-tested defense", "Superior free throw efficiency"],
    proTeam2: ["Eric Gaines has 6+ steals in 3 of last 5 games", "American conference has 3 tournament teams", "High activity defense disrupts post entries", "UAB has experience with pressure situations"]
  },
  {
    id: "east-r1-6", round: 1, region: "East",
    team1: EAST_TEAMS[10], team2: EAST_TEAMS[11], // 6 vs 11
    rotobotPick: "creighton", rotobotConfidence: 72,
    location: "Indianapolis, IN",
    analysis: "Creighton's three-point bombing paired with Kalkbrenner's interior presence creates matchup problems Loyola struggles to solve. However, Loyola's deliberate pace and disciplined defense gives them a real path — especially if they can limit three-point attempts.",
    proTeam1: ["Ryan Kalkbrenner draws double teams creating open threes", "Big East is the best conference for guard development", "Deep shooting rotation (5 players above 37% from three)", "Creighton is 8-2 in their last 10 first-round games"],
    proTeam2: ["Sister Jean is back and defenses can't guard vibes", "Loyola's 63.8 pace neutralizes Creighton's transition game", "Drew Knapper is a 23-year-old grad student with ice in his veins", "Defensive discipline limits high-scoring opponents"]
  },
  {
    id: "east-r1-7", round: 1, region: "East",
    team1: EAST_TEAMS[12], team2: EAST_TEAMS[13], // 7 vs 10
    rotobotPick: "texas-am", rotobotConfidence: 62,
    location: "Memphis, TN",
    analysis: "This is the tightest first-round game in the East. Penn State and Texas A&M are nearly identical statistically. Penn State's momentum late in the Big Ten season gives them a slight edge, but RotoBot's model shows less than 4% separation. Flip a coin.",
    proTeam1: ["SEC physicality is tournament gold", "Buzz Williams' defensive schemes create chaos", "Tyrece Radford's experience in big games", "Superior rebounding differential"],
    proTeam2: ["Aljami Durham averages 5.0 APG — elite playmaking", "Big Ten schedule ranked #4 in the country", "Penn State has won 7 of last 9 entering the tournament", "Three-point shooting (38.2%) can stretch any defense"]
  },
  {
    id: "east-r1-8", round: 1, region: "East",
    team1: EAST_TEAMS[14], team2: EAST_TEAMS[15], // 8 vs 9
    rotobotPick: "north-carolina", rotobotConfidence: 55,
    location: "Memphis, TN",
    analysis: "The quintessential 8-9 game — a true toss-up. UNC's offensive firepower is tremendous but their defense is the fourth-worst among tournament teams. Mississippi State's physicality can grind UNC into a defensive battle. RotoBot's model: 55-45 North Carolina.",
    proTeam1: ["Elliot Cadeau is an elite first-round-caliber PG", "Best offensive rating in the ACC", "Hubert Davis' tournament experience as player and coach", "High-tempo style wears teams down late"],
    proTeam2: ["SEC defensive DNA is built for tournament basketball", "Cameron Matthews is a 6'7\" defender who can guard 1-4", "Mississippi State +8 in rebounding margin vs ranked opponents", "Jon Cooper transfer has elevated frontcourt dramatically"]
  }
];

export const WEST_R1_GAMES: Game[] = [
  {
    id: "west-r1-1", round: 1, region: "West",
    team1: WEST_TEAMS[0], team2: WEST_TEAMS[1],
    rotobotPick: "auburn", rotobotConfidence: 98,
    location: "Salt Lake City, UT",
    analysis: "Johni Broome is the most dominant player in the country and Auburn's complete team will be a wagon all tournament long.",
    proTeam1: ["Johni Broome is the clear Naismith favorite", "Auburn is 15-0 in neutral site games this season", "Elite offense AND defense — rare combination", "Deepest bench in the tournament"],
    proTeam2: ["MEAC champion earns automatic respect", "Christian Ings can erupt for 30", "Upset history means no team is safe", "Low-pressure first-round game"]
  },
  {
    id: "west-r1-2", round: 1, region: "West",
    team1: WEST_TEAMS[2], team2: WEST_TEAMS[3],
    rotobotPick: "arizona", rotobotConfidence: 92,
    location: "Salt Lake City, UT",
    analysis: "Arizona's depth and Tommy Lloyd's offensive system are at their peak. KJ Lewis has emerged as an elite scorer and defender.",
    proTeam1: ["Best offensive system in the Pac-12+ era", "KJ Lewis has lottery-pick upside", "Seven players average 8+ points per game", "Strong rebounding edge"],
    proTeam2: ["Colgate's guard-oriented offense can score quickly", "Tucker Richardson has hit 5+ threes in two recent games", "Matt Langel is a proven mid-major tournament coach", "Low-possession style can keep it close"]
  },
  {
    id: "west-r1-3", round: 1, region: "West",
    team1: WEST_TEAMS[4], team2: WEST_TEAMS[5],
    rotobotPick: "gonzaga", rotobotConfidence: 86,
    location: "Denver, CO",
    analysis: "Gonzaga's tournament DNA and Mark Few's adjustments make them perennially dangerous. Braden Huff's emergence gives them a post anchor they've lacked in recent years.",
    proTeam1: ["Mark Few is 0-0 in first round games since 2020", "Braden Huff is a matchup nightmare at 7'1\"", "WCC regular season is misleading — SOS tells the real story", "Elite assist-to-turnover ratio means high-IQ basketball"],
    proTeam2: ["Jovan Blacksher Jr. scored 41 in conference tournament final", "GCU has advanced past the first round in 2 of last 3 years", "High-pace offense can rattle Gonzaga early", "Nothing to lose creates fearless play"]
  },
  {
    id: "west-r1-4", round: 1, region: "West",
    team1: WEST_TEAMS[6], team2: WEST_TEAMS[7],
    rotobotPick: "iowa-state", rotobotConfidence: 78,
    location: "Denver, CO",
    analysis: "Iowa State's defense is built for March. They've held opponents under 65 points in 12 games. Yale's efficiency offense is good but not good enough to overcome ISU's size and defensive activity.",
    proTeam1: ["#1 defensive efficiency in the Big 12 tournament", "Milan Momcilovic is shooting 41% from three lately", "T.J. Otzelberger won his first 8 career NCAA games", "Physical advantage at every frontcourt position"],
    proTeam2: ["John Poulakidas hit 41 three-pointers on the season", "Yale's 54.2% eFG is elite even for power conference standards", "Ivy League prep keeps teams mentally sharp", "Efficient offense = fewer possessions needed"]
  },
  {
    id: "west-r1-5", round: 1, region: "West",
    team1: WEST_TEAMS[8], team2: WEST_TEAMS[9],
    rotobotPick: "michigan-state", rotobotConfidence: 71,
    location: "Portland, OR",
    analysis: "Tom Izzo's record in the tournament speaks for itself. Michigan State is 7-2 in first-round games under him in the last decade. JMU's guard play will create opportunities but Spartans' experience will win out.",
    proTeam1: ["Tom Izzo: 26 NCAA tournament wins", "Coen Carr's athleticism disrupts transition offense", "Big Ten physicality is unmatched preparation", "Elite defensive rebounding (33.4%)"],
    proTeam2: ["12 seeds win 35% of first-round games historically", "Terrence Edwards Jr. is a legitimate Player of the Year candidate", "JMU's transition offense scores 18+ points per game", "Underdog mentality fuels March Magic runs"]
  },
  {
    id: "west-r1-6", round: 1, region: "West",
    team1: WEST_TEAMS[10], team2: WEST_TEAMS[11],
    rotobotPick: "st-johns", rotobotConfidence: 69,
    location: "Portland, OR",
    analysis: "Rick Pitino's tournament mastery is real but so is Texas' talent. RJ Luis Jr. against Tre Johnson is the matchup of the first round. St. John's depth and Big East grind gives them the edge in this volatile game.",
    proTeam1: ["Rick Pitino has 14 Elite Eight appearances", "RJ Luis Jr. outscores opponents by 12 in big games", "Big East battle-tested schedule", "Strong defensive rebounding limits second chances"],
    proTeam2: ["Tre Johnson is going top-5 in the NBA Draft", "Texas is 4-1 ATS as an underdog since January", "SEC physicality transitions to neutral courts", "First-round motivation for Longhorns is sky-high"]
  },
  {
    id: "west-r1-7", round: 1, region: "West",
    team1: WEST_TEAMS[12], team2: WEST_TEAMS[13],
    rotobotPick: "clemson", rotobotConfidence: 65,
    location: "Seattle, WA",
    analysis: "Clemson's defense is elite but Xavier's scoring can erupt. Brad Brownell's experience in close games is the difference-maker here in a game that could go to overtime.",
    proTeam1: ["Best defensive efficiency in the ACC", "Chase Hunter is a 23-year-old grad student veteran", "Brownell has won 3 of his last 4 first-round games", "Rebounding edge of +4.2 per game"],
    proTeam2: ["Dayvion McKnight scored 28+ in 4 Big East games", "Xavier has more top-80 KenPom wins than seed suggests", "Big East schedule is elite tournament preparation", "Historical X factors include a talented transfer class"]
  },
  {
    id: "west-r1-8", round: 1, region: "West",
    team1: WEST_TEAMS[14], team2: WEST_TEAMS[15],
    rotobotPick: "oklahoma", rotobotConfidence: 52,
    location: "Seattle, WA",
    analysis: "The closest game on the board. VJ Edgecombe vs Javian McCollum is must-watch basketball. Both teams are tournament-caliber with near-identical defensive ratings. RotoBot's tiny edge to Oklahoma is based on their recent 7-game winning streak.",
    proTeam1: ["Scott Drew has 4 Sweet 16 appearances in last 6 years", "VJ Edgecombe is a Bahamas national team star with international experience", "NBA-style guard-forward system is hard to scout in a week", "Superior assist rate creates high-percentage looks"],
    proTeam2: ["Oklahoma won 7 straight entering the tournament", "Javian McCollum put up 28/8/6 in SEC tournament win", "Porter Moser beat Drew twice in Big 12 play this year", "SEC strength of schedule advantage over Big 12"]
  }
];

export const REGIONS = ["East", "West", "South", "Midwest"];

export const FINAL_FOUR_PROJECTIONS = [
  { team: EAST_TEAMS[0], path: "East Region Champion", confidence: 68 },
  { team: WEST_TEAMS[0], path: "West Region Champion", confidence: 72 },
  { team: SOUTH_TEAMS[0], path: "South Region Champion", confidence: 61 },
  { team: MIDWEST_TEAMS[0], path: "Midwest Region Champion", confidence: 65 },
];

export const CHAMPIONSHIP_PREDICTION = {
  team1: WEST_TEAMS[0], // Auburn
  team2: EAST_TEAMS[0], // Duke
  pick: WEST_TEAMS[0],
  confidence: 58,
  analysis: "The rematch we've all been waiting for. Auburn's Johni Broome vs Duke's Cooper Flagg is a generational matchup. RotoBot gives Auburn the edge based on superior rebounding and schedule strength, but this is truly a coin-flip between two transcendent teams."
};
