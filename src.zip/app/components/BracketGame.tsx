import { Link } from "react-router";
import { Brain, ChevronRight } from "lucide-react";
import type { Game } from "../data/bracketData";

interface BracketGameProps {
  game: Game;
  userPick?: string;
  onPick?: (gameId: string, teamId: string) => void;
  compact?: boolean;
}

export function BracketGameCard({ game, userPick, onPick, compact = false }: BracketGameProps) {
  const rotobotTeam = game.team1.id === game.rotobotPick ? game.team1 : game.team2;

  return (
    <Link
      to={`/matchup/${game.id}`}
      className="no-underline block"
      onClick={(e) => e.stopPropagation()}
    >
      <div
        className="rounded-xl overflow-hidden transition-all hover:border-[rgba(0,184,219,0.3)] group"
        style={{
          background: "rgba(255,255,255,0.03)",
          border: "1px solid rgba(255,255,255,0.08)",
          minWidth: compact ? 160 : 200,
        }}
      >
        {[game.team1, game.team2].map((team, idx) => {
          const isRotoPick = team.id === game.rotobotPick;
          const isUserPick = team.id === userPick;
          const isTop = idx === 0;

          return (
            <div
              key={team.id}
              onClick={(e) => {
                e.preventDefault();
                onPick?.(game.id, team.id);
              }}
              className="flex items-center gap-2 px-2.5 py-2 cursor-pointer transition-all hover:bg-white/5"
              style={{
                borderBottom: isTop ? "1px solid rgba(255,255,255,0.06)" : "none",
                background: isUserPick ? "rgba(0,184,219,0.08)" : "transparent",
              }}
            >
              {/* Seed */}
              <div
                className="flex items-center justify-center rounded shrink-0"
                style={{
                  width: 18,
                  height: 18,
                  background: isRotoPick ? "rgba(0,184,219,0.18)" : "rgba(255,255,255,0.06)",
                  fontFamily: "Rubik, sans-serif",
                  fontSize: 9,
                  fontWeight: 700,
                  color: isRotoPick ? "#00b8db" : "rgba(255,255,255,0.4)",
                }}
              >
                {team.seed}
              </div>

              {/* Team color dot */}
              <div className="w-2 h-2 rounded-full shrink-0" style={{ background: team.color }} />

              {/* Name */}
              <span
                className="flex-1 truncate"
                style={{
                  fontFamily: "Rubik, sans-serif",
                  fontSize: compact ? 11 : 12,
                  fontWeight: isRotoPick || isUserPick ? 600 : 400,
                  color: isRotoPick || isUserPick ? "white" : "rgba(255,255,255,0.55)",
                }}
              >
                {compact ? team.shortName.slice(0, 12) : team.shortName}
              </span>

              {/* Indicators */}
              <div className="flex items-center gap-1">
                {isUserPick && (
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: "#22c55e" }} />
                )}
                {isRotoPick && !compact && (
                  <Brain size={9} color="#00b8db" />
                )}
              </div>
            </div>
          );
        })}

        {/* Confidence bar */}
        {!compact && (
          <div className="px-2.5 py-1.5" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="flex items-center gap-1.5">
              <div className="flex-1 h-0.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${game.rotobotConfidence}%`,
                    background: game.rotobotConfidence >= 80 ? "#00b8db" : game.rotobotConfidence >= 60 ? "#3c84ff" : "#f59e0b",
                  }}
                />
              </div>
              <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 9, color: "rgba(255,255,255,0.3)", minWidth: 24, textAlign: "right" }}>
                {game.rotobotConfidence}%
              </span>
            </div>
          </div>
        )}
      </div>
    </Link>
  );
}

// Connector SVG between rounds
export function BracketConnector({ count, height }: { count: number; height: number }) {
  const segmentH = height / count;
  const lines: React.ReactNode[] = [];

  for (let i = 0; i < count / 2; i++) {
    const topY = segmentH * (2 * i) + segmentH / 2;
    const bottomY = segmentH * (2 * i + 1) + segmentH / 2;
    const midY = (topY + bottomY) / 2;

    lines.push(
      <g key={i}>
        <line x1="0" y1={topY} x2="16" y2={topY} stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
        <line x1="0" y1={bottomY} x2="16" y2={bottomY} stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
        <line x1="16" y1={topY} x2="16" y2={bottomY} stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
        <line x1="16" y1={midY} x2="32" y2={midY} stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
      </g>
    );
  }

  return (
    <svg width="32" height={height} style={{ display: "block", flexShrink: 0 }}>
      {lines}
    </svg>
  );
}
