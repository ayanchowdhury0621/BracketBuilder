import { Outlet } from "react-router";
import { Navbar, BottomNav } from "./Navbar";

export function Layout() {
  return (
    <div style={{ minHeight: "100vh" }}>
      <Navbar />
      <Outlet />
      <BottomNav />
    </div>
  );
}
