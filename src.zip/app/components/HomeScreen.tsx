import { Link } from "react-router";
import { Trophy, TrendingUp, Brain, Zap, ArrowRight, Star, Target, ChevronRight } from "lucide-react";
import { RotoBotLogo } from "./RotoBotLogo";
import { EAST_R1_GAMES, WEST_R1_GAMES, CHAMPIONSHIP_PREDICTION, FINAL_FOUR_PROJECTIONS } from "../data/bracketData";

function ConfidenceBar({ value, label }: { value: number; label?: string }) {
  const color = value >= 80 ? "#00b8db" : value >= 60 ? "#3c84ff" : value >= 40 ? "#f59e0b" : "#ef4444";
  return (
    <div className="flex items-center gap-2">
      {label && (
        <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.5)", minWidth: 24 }}>
          {label}
        </span>
      )}
      <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.1)" }}>
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${value}%`, background: color }}
        />
      </div>
      <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, fontWeight: 600, color, minWidth: 32, textAlign: "right" }}>
        {value}%
      </span>
    </div>
  );
}

function TeamSeedBadge({ seed, color }: { seed: number; color: string }) {
  return (
    <div
      className="flex items-center justify-center rounded-md shrink-0"
      style={{
        width: 22,
        height: 22,
        background: `${color}22`,
        border: `1px solid ${color}44`,
        fontFamily: "Rubik, sans-serif",
        fontSize: 11,
        fontWeight: 700,
        color,
      }}
    >
      {seed}
    </div>
  );
}

function FeaturedMatchup({ game }: { game: (typeof EAST_R1_GAMES)[0] }) {
  return (
    <Link
      to={`/matchup/${game.id}`}
      className="no-underline block rounded-2xl overflow-hidden transition-transform hover:-translate-y-0.5"
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <div
            className="px-2 py-0.5 rounded-full"
            style={{
              background: "rgba(0,184,219,0.12)",
              border: "1px solid rgba(0,184,219,0.2)",
              fontFamily: "Rubik, sans-serif",
              fontSize: 10,
              fontWeight: 600,
              color: "#00b8db",
              textTransform: "uppercase",
              letterSpacing: "0.5px",
            }}
          >
            {game.region} • R1
          </div>
          <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
            {game.location}
          </span>
        </div>

        {/* Teams */}
        <div className="flex flex-col gap-2 mb-3">
          {[game.team1, game.team2].map((team, i) => {
            const isPick = game.rotobotPick === team.id;
            return (
              <div key={team.id} className="flex items-center gap-2.5">
                <TeamSeedBadge seed={team.seed} color={isPick ? "#00b8db" : "rgba(255,255,255,0.3)"} />
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                  style={{ background: `${team.color}33`, border: `1px solid ${team.color}55` }}
                >
                  <span style={{ fontSize: 10, color: "white", fontWeight: 700 }}>
                    {team.shortName.slice(0, 2).toUpperCase()}
                  </span>
                </div>
                <span
                  style={{
                    fontFamily: "Rubik, sans-serif",
                    fontSize: 13,
                    fontWeight: isPick ? 600 : 400,
                    color: isPick ? "white" : "rgba(255,255,255,0.6)",
                    flex: 1,
                  }}
                >
                  {team.shortName}
                </span>
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
                  {team.record}
                </span>
                {isPick && (
                  <div
                    className="flex items-center gap-1 px-2 py-0.5 rounded-full"
                    style={{ background: "rgba(0,184,219,0.15)", border: "1px solid rgba(0,184,219,0.3)" }}
                  >
                    <Brain size={9} color="#00b8db" />
                    <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 600, color: "#00b8db" }}>
                      PICK
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Confidence */}
        <ConfidenceBar value={game.rotobotConfidence} />

        {/* Quick blurb */}
        <p
          className="mt-3 line-clamp-2"
          style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.45)", lineHeight: 1.5 }}
        >
          {game.analysis.slice(0, 120)}...
        </p>
      </div>
    </Link>
  );
}

function StatCard({ icon: Icon, value, label, sub, color }: {
  icon: React.ElementType; value: string; label: string; sub?: string; color: string;
}) {
  return (
    <div
      className="flex flex-col gap-2 p-4 rounded-2xl"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
    >
      <div className="flex items-center gap-2">
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: `${color}18` }}
        >
          <Icon size={15} color={color} />
        </div>
        <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.45)", fontWeight: 400 }}>
          {label}
        </span>
      </div>
      <div>
        <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 26, fontWeight: 700, color: "white", lineHeight: 1 }}>
          {value}
        </div>
        {sub && (
          <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color, marginTop: 3 }}>
            {sub}
          </div>
        )}
      </div>
    </div>
  );
}

export function HomeScreen() {
  const featuredGames = [EAST_R1_GAMES[3], EAST_R1_GAMES[4], WEST_R1_GAMES[7], EAST_R1_GAMES[7]];

  return (
    <div
      className="min-h-screen pt-16 pb-20 md:pb-8"
      style={{ background: "linear-gradient(160deg, #010c2a 0%, #030712 40%, #00081e 100%)" }}
    >
      {/* Ambient glows */}
      <div
        className="fixed pointer-events-none"
        style={{
          top: 0, left: "30%", width: 600, height: 400,
          background: "radial-gradient(ellipse, rgba(0,184,219,0.08) 0%, transparent 70%)",
        }}
      />
      <div
        className="fixed pointer-events-none"
        style={{
          top: "40%", left: "-5%", width: 400, height: 400,
          background: "radial-gradient(ellipse, rgba(60,132,255,0.06) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 relative">
        {/* Hero */}
        <div className="flex flex-col md:flex-row md:items-center gap-8 mb-10">
          <div className="flex-1">
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-4"
              style={{
                background: "rgba(0,184,219,0.1)",
                border: "1px solid rgba(0,184,219,0.25)",
              }}
            >
              <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "#00b8db" }} />
              <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, fontWeight: 600, color: "#00b8db" }}>
                2025–26 March Madness • Bracket Preview Mode
              </span>
            </div>

            <h1
              style={{
                fontFamily: "Rubik, sans-serif",
                fontSize: "clamp(32px, 5vw, 54px)",
                fontWeight: 800,
                color: "white",
                lineHeight: 1.1,
                letterSpacing: "-1px",
                marginBottom: 16,
              }}
            >
              Build Your <br />
              <span style={{ background: "linear-gradient(90deg, #00b8db, #3c84ff)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Smarter Bracket
              </span>
            </h1>

            <p style={{ fontFamily: "Rubik, sans-serif", fontSize: 16, color: "rgba(255,255,255,0.55)", lineHeight: 1.6, maxWidth: 480, marginBottom: 24 }}>
              RotoBot analyzes thousands of data points — efficiency ratings, pace, recent form, and matchup history — to give you AI-powered insights on every single game.
            </p>

            <div className="flex flex-wrap gap-3">
              <Link
                to="/bracket"
                className="no-underline flex items-center gap-2 px-5 py-3 rounded-xl transition-all hover:opacity-90"
                style={{
                  background: "linear-gradient(135deg, #00b8db 0%, #3c84ff 100%)",
                  fontFamily: "Rubik, sans-serif",
                  fontWeight: 600,
                  fontSize: 15,
                  color: "white",
                }}
              >
                <Trophy size={16} />
                Build My Bracket
              </Link>
              <Link
                to="/analysis"
                className="no-underline flex items-center gap-2 px-5 py-3 rounded-xl transition-all"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  fontFamily: "Rubik, sans-serif",
                  fontWeight: 500,
                  fontSize: 15,
                  color: "rgba(255,255,255,0.8)",
                }}
              >
                <Brain size={16} />
                Explore Analysis
              </Link>
            </div>
          </div>

          {/* Championship prediction card */}
          <div
            className="md:w-80 shrink-0 rounded-2xl overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(0,184,219,0.08) 0%, rgba(60,132,255,0.08) 100%)",
              border: "1px solid rgba(0,184,219,0.2)",
            }}
          >
            <div className="px-5 pt-5 pb-4">
              <div className="flex items-center gap-2 mb-4">
                <Star size={14} color="#00b8db" />
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, fontWeight: 700, color: "#00b8db", textTransform: "uppercase", letterSpacing: "1px" }}>
                  RotoBot Championship Prediction
                </span>
              </div>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "#003087", border: "1px solid rgba(255,255,255,0.15)" }}>
                      <span style={{ color: "white", fontSize: 11, fontWeight: 800 }}>AUB</span>
                    </div>
                    <div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, fontWeight: 700, color: "white" }}>Auburn</div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.4)" }}>#1 West • 27-2</div>
                    </div>
                  </div>
                  <div className="text-center py-1">
                    <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.3)", fontWeight: 500 }}>vs</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "#002F87", border: "1px solid rgba(255,255,255,0.15)" }}>
                      <span style={{ color: "white", fontSize: 11, fontWeight: 800 }}>DUK</span>
                    </div>
                    <div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, fontWeight: 700, color: "white" }}>Duke</div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.4)" }}>#1 East • 26-3</div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <div
                    className="flex items-center justify-center rounded-full"
                    style={{ width: 64, height: 64, background: "linear-gradient(135deg, #00b8db22, #3c84ff22)", border: "2px solid rgba(0,184,219,0.4)" }}
                  >
                    <div className="text-center">
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 18, fontWeight: 800, color: "#00b8db", lineHeight: 1 }}>
                        {CHAMPIONSHIP_PREDICTION.confidence}%
                      </div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 8, color: "rgba(0,184,219,0.7)", textTransform: "uppercase" }}>
                        Auburn
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <p style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.45)", lineHeight: 1.5 }}>
                {CHAMPIONSHIP_PREDICTION.analysis.slice(0, 100)}...
              </p>
              <Link
                to="/matchup/championship"
                className="no-underline flex items-center gap-1 mt-3"
                style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "#00b8db", fontWeight: 500 }}
              >
                Full analysis <ChevronRight size={12} />
              </Link>
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
          <StatCard icon={Trophy} value="68" label="Teams Analyzed" sub="+ 4 auto-bids" color="#00b8db" />
          <StatCard icon={Brain} value="2,847" label="Data Points" sub="per matchup" color="#3c84ff" />
          <StatCard icon={Target} value="74.2%" label="AI Accuracy" sub="2024 bracket" color="#22c55e" />
          <StatCard icon={Zap} value="12" label="Days to Lock" sub="Bracket seeds drop" color="#f59e0b" />
        </div>

        {/* Final Four Projections */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-4">
            <h2 style={{ fontFamily: "Rubik, sans-serif", fontSize: 18, fontWeight: 700, color: "white" }}>
              Projected Final Four
            </h2>
            <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
              RotoBot AI • Feb 2026
            </span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {FINAL_FOUR_PROJECTIONS.map((proj) => (
              <div
                key={proj.team.id}
                className="rounded-2xl p-4"
                style={{
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.07)",
                }}
              >
                <div
                  className="inline-block px-2 py-0.5 rounded-full mb-3"
                  style={{ background: "rgba(0,184,219,0.1)", fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 600, color: "#00b8db" }}
                >
                  {proj.path.replace(" Region Champion", "")}
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                    style={{ background: `${proj.team.color}33`, border: `1px solid ${proj.team.color}66` }}
                  >
                    <span style={{ color: "white", fontSize: 9, fontWeight: 800 }}>
                      {proj.team.shortName.slice(0, 3).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 600, color: "white" }}>
                      {proj.team.shortName}
                    </div>
                    <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.35)" }}>
                      #{proj.team.seed} • {proj.team.record}
                    </div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.4)" }}>Confidence</span>
                    <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 600, color: "#00b8db" }}>{proj.confidence}%</span>
                  </div>
                  <div className="h-1 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
                    <div className="h-full rounded-full" style={{ width: `${proj.confidence}%`, background: "linear-gradient(90deg, #00b8db, #3c84ff)" }} />
                  </div>
                </div>
                <p className="mt-2" style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.35)", lineHeight: 1.4 }}>
                  {proj.team.rotobotBlurb.slice(0, 60)}...
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Featured Matchups */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 style={{ fontFamily: "Rubik, sans-serif", fontSize: 18, fontWeight: 700, color: "white" }}>
                Games to Watch
              </h2>
              <p style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>
                RotoBot's highest-intrigue first-round matchups
              </p>
            </div>
            <Link
              to="/bracket"
              className="no-underline flex items-center gap-1"
              style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, color: "#00b8db", fontWeight: 500 }}
            >
              View all <ArrowRight size={13} />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {featuredGames.map((game) => (
              <FeaturedMatchup key={game.id} game={game} />
            ))}
          </div>
        </div>

        {/* Top upset picks */}
        <div
          className="rounded-2xl p-5"
          style={{
            background: "linear-gradient(135deg, rgba(245,158,11,0.06) 0%, rgba(239,68,68,0.04) 100%)",
            border: "1px solid rgba(245,158,11,0.15)",
          }}
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} color="#f59e0b" />
            <h2 style={{ fontFamily: "Rubik, sans-serif", fontSize: 16, fontWeight: 700, color: "white" }}>
              RotoBot's Top Upset Alerts
            </h2>
            <div
              className="px-2 py-0.5 rounded-full ml-auto"
              style={{ background: "rgba(245,158,11,0.15)", fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 600, color: "#f59e0b" }}
            >
              HIGH CONFIDENCE
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { seed1: 12, team1: "UAB", seed2: 5, team2: "Purdue", probability: 32, region: "East", note: "Eric Gaines' pressure defense disrupts Purdue's post-entry game" },
              { seed1: 11, team1: "Loyola Chi.", seed2: 6, team2: "Creighton", probability: 28, region: "East", note: "Low-pace game neutralizes Creighton's three-point barrage" },
              { seed1: 9, team1: "Oklahoma", seed2: 8, team2: "Baylor", probability: 48, region: "West", note: "Oklahoma's 7-game streak vs Baylor's inconsistent form" },
            ].map((upset, i) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3 rounded-xl"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                  style={{ background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.25)" }}
                >
                  <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, fontWeight: 700, color: "#f59e0b" }}>
                    {upset.probability}%
                  </span>
                </div>
                <div>
                  <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 600, color: "white" }}>
                    #{upset.seed1} {upset.team1} over #{upset.seed2} {upset.team2}
                  </div>
                  <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.35)", marginTop: 2 }}>
                    {upset.region} Region
                  </div>
                  <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.5)", marginTop: 4, lineHeight: 1.4 }}>
                    {upset.note}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
