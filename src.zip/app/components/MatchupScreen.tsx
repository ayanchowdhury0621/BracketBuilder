import { useState } from "react";
import { useParams, Link } from "react-router";
import {
  Brain, ChevronLeft, TrendingUp,
  Target, Zap, BarChart2, CheckCircle2
} from "lucide-react";
import {
  EAST_R1_GAMES, WEST_R1_GAMES,
  SOUTH_TEAMS, MIDWEST_TEAMS, type Game, type Team
} from "../data/bracketData";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer, Tooltip } from "recharts";

// Combine all games
function buildGames(teams: Team[], region: string): Game[] {
  const pairs = [[0,1],[2,3],[4,5],[6,7],[8,9],[10,11],[12,13],[14,15]];
  return pairs.map((pair, i) => {
    const t1 = teams[pair[0]];
    const t2 = teams[pair[1]];
    const pick = t1.rotobotScore > t2.rotobotScore ? t1.id : t2.id;
    const confidence = Math.min(98, Math.max(51, 50 + Math.abs(t1.rotobotScore - t2.rotobotScore) * 2.5));
    return {
      id: `${region.toLowerCase()}-r1-${i+1}`,
      round: 1,
      region,
      team1: t1, team2: t2,
      rotobotPick: pick,
      rotobotConfidence: Math.round(confidence),
      location: "TBD",
      analysis: `${t1.shortName} vs ${t2.shortName}`,
      proTeam1: [t1.rotobotBlurb, `${t1.ppg} PPG offense ranked top-40 nationally`, `${(100 - t1.tovPct).toFixed(1)}% shot quality`, `Recent form: ${t1.recentForm.join("-")}`],
      proTeam2: [t2.rotobotBlurb, `${t2.ppg} PPG offense with efficient shooting`, `${t2.conference} schedule provides tournament experience`, `${t2.keyPlayer}: ${t2.keyPlayerStat}`],
    };
  });
}

const ALL_GAMES: Game[] = [
  ...EAST_R1_GAMES,
  ...WEST_R1_GAMES,
  ...buildGames(SOUTH_TEAMS, "South"),
  ...buildGames(MIDWEST_TEAMS, "Midwest"),
];

const SAMPLE_GAME: Game = EAST_R1_GAMES[3]; // UCLA vs Vermont - tight matchup

function StatBar({ label, val1, val2, higherIsBetter = true }: {
  label: string; val1: number; val2: number; higherIsBetter?: boolean;
}) {
  const total = val1 + val2 || 1;
  const pct1 = (val1 / total) * 100;
  const winner1 = higherIsBetter ? val1 > val2 : val1 < val2;
  const winner2 = higherIsBetter ? val2 > val1 : val2 < val1;
  const cyan = "#00b8db";
  const blue = "#3c84ff";

  return (
    <div className="flex items-center gap-3">
      <div
        className="text-right"
        style={{
          fontFamily: "Rubik, sans-serif",
          fontSize: 13,
          fontWeight: winner1 ? 700 : 400,
          color: winner1 ? cyan : "rgba(255,255,255,0.55)",
          minWidth: 48,
        }}
      >
        {val1}
      </div>
      <div className="flex-1 flex flex-col gap-1">
        <div className="flex h-2 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
          <div style={{ width: `${pct1}%`, background: cyan, borderRadius: "4px 0 0 4px" }} />
          <div style={{ flex: 1, background: blue, borderRadius: "0 4px 4px 0" }} />
        </div>
        <div className="text-center" style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "0.5px" }}>
          {label}
        </div>
      </div>
      <div
        style={{
          fontFamily: "Rubik, sans-serif",
          fontSize: 13,
          fontWeight: winner2 ? 700 : 400,
          color: winner2 ? blue : "rgba(255,255,255,0.55)",
          minWidth: 48,
          textAlign: "right",
        }}
      >
        {val2}
      </div>
    </div>
  );
}

function FormBadge({ result }: { result: "W" | "L" }) {
  return (
    <div
      className="w-6 h-6 rounded flex items-center justify-center"
      style={{
        background: result === "W" ? "rgba(34,197,94,0.15)" : "rgba(239,68,68,0.12)",
        border: `1px solid ${result === "W" ? "rgba(34,197,94,0.3)" : "rgba(239,68,68,0.25)"}`,
        fontFamily: "Rubik, sans-serif",
        fontSize: 10,
        fontWeight: 700,
        color: result === "W" ? "#22c55e" : "#ef4444",
      }}
    >
      {result}
    </div>
  );
}

function TeamHeader({ team, isPick, confidence, side }: {
  team: Team; isPick: boolean; confidence: number; side: "left" | "right";
}) {
  const cyan = "#00b8db";
  const blue = "#3c84ff";
  const color = side === "left" ? cyan : blue;
  const align = side === "left" ? "left" : "right";
  const flexDir = side === "left" ? "flex-row" : "flex-row-reverse";

  return (
    <div className={`flex-1 flex ${flexDir} items-start gap-4`}>
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center shrink-0"
        style={{
          background: `${team.color}22`,
          border: `2px solid ${isPick ? color : team.color + "44"}`,
          boxShadow: isPick ? `0 0 20px ${color}30` : "none",
        }}
      >
        <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 800, color: "white" }}>
          {team.shortName.slice(0, 3).toUpperCase()}
        </span>
      </div>
      <div className={`text-${align}`}>
        <div className="flex items-center gap-2 mb-0.5" style={{ flexDirection: side === "right" ? "row-reverse" : "row" }}>
          <div
            className="px-2 py-0.5 rounded-full"
            style={{
              background: `${color}18`,
              border: `1px solid ${color}30`,
              fontFamily: "Rubik, sans-serif",
              fontSize: 10,
              fontWeight: 700,
              color,
            }}
          >
            #{team.seed}
          </div>
          {isPick && (
            <div
              className="flex items-center gap-1 px-2 py-0.5 rounded-full"
              style={{ background: "rgba(0,184,219,0.12)", border: "1px solid rgba(0,184,219,0.3)" }}
            >
              <Brain size={9} color="#00b8db" />
              <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 9, fontWeight: 700, color: "#00b8db" }}>
                ROTOBOT PICK
              </span>
            </div>
          )}
        </div>
        <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 20, fontWeight: 800, color: "white", letterSpacing: "-0.3px" }}>
          {team.name.split(" ").slice(0, -1).join(" ")}
        </div>
        <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, color, fontWeight: 600 }}>
          {team.name.split(" ").slice(-1)}
        </div>
        <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>
          {team.record} • {team.conference}
        </div>
        {isPick && (
          <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 700, color, marginTop: 4 }}>
            {confidence}% confidence
          </div>
        )}
      </div>
    </div>
  );
}

export function MatchupScreen() {
  const { id } = useParams<{ id: string }>();
  const [viewMode, setViewMode] = useState<"quick" | "deep">("quick");
  const [userPick, setUserPick] = useState<string | null>(null);

  const game = ALL_GAMES.find(g => g.id === id) || SAMPLE_GAME;
  const { team1, team2 } = game;
  const rotobotTeam = game.rotobotPick === team1.id ? team1 : team2;

  const radarData = [
    { subject: "Offense", A: team1.ppg / 90 * 100, B: team2.ppg / 90 * 100 },
    { subject: "Defense", A: (90 - team1.oppg) / 90 * 100, B: (90 - team2.oppg) / 90 * 100 },
    { subject: "Pace", A: team1.pace / 80 * 100, B: team2.pace / 80 * 100 },
    { subject: "Shooting", A: team1.eFGPct, B: team2.eFGPct },
    { subject: "Ball Care", A: (25 - team1.tovPct) / 25 * 100, B: (25 - team2.tovPct) / 25 * 100 },
    { subject: "Rebounding", A: team1.orebPct, B: team2.orebPct },
    { subject: "Schedule", A: Math.max(0, (360 - team1.sosRank) / 360 * 100), B: Math.max(0, (360 - team2.sosRank) / 360 * 100) },
  ];

  return (
    <div
      className="min-h-screen pt-16 pb-20 md:pb-8"
      style={{ background: "linear-gradient(160deg, #010c2a 0%, #030712 50%, #00081e 100%)" }}
    >
      {/* Ambient */}
      <div className="fixed pointer-events-none" style={{ top: 60, left: "20%", width: 600, height: 400, background: "radial-gradient(ellipse, rgba(0,184,219,0.05) 0%, transparent 70%)" }} />
      <div className="fixed pointer-events-none" style={{ top: "40%", right: "10%", width: 400, height: 400, background: "radial-gradient(ellipse, rgba(60,132,255,0.05) 0%, transparent 70%)" }} />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 relative">
        {/* Back */}
        <Link
          to="/bracket"
          className="no-underline inline-flex items-center gap-2 mb-6 transition-opacity hover:opacity-70"
          style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, color: "rgba(255,255,255,0.4)", fontWeight: 500 }}
        >
          <ChevronLeft size={15} />
          Back to Bracket
        </Link>

        {/* Game meta */}
        <div className="flex items-center gap-3 mb-6">
          <div
            className="px-3 py-1 rounded-full"
            style={{
              background: "rgba(0,184,219,0.1)",
              border: "1px solid rgba(0,184,219,0.2)",
              fontFamily: "Rubik, sans-serif",
              fontSize: 11,
              fontWeight: 700,
              color: "#00b8db",
              textTransform: "uppercase",
              letterSpacing: "0.5px",
            }}
          >
            {game.region} Region • Round 1
          </div>
          <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
            {game.location}
          </span>
          <div
            className="ml-auto px-3 py-1 rounded-full flex items-center gap-1.5"
            style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.15)" }}
          >
            <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "#22c55e" }} />
            <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, fontWeight: 600, color: "#22c55e" }}>
              AI Analysis Ready
            </span>
          </div>
        </div>

        {/* Teams header */}
        <div
          className="flex items-center gap-4 p-5 rounded-2xl mb-6"
          style={{
            background: "rgba(255,255,255,0.03)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <TeamHeader team={team1} isPick={game.rotobotPick === team1.id} confidence={game.rotobotConfidence} side="left" />

          {/* VS / Score */}
          <div className="flex flex-col items-center gap-3 shrink-0">
            <div
              className="px-4 py-1.5 rounded-xl"
              style={{
                background: "rgba(255,255,255,0.06)",
                fontFamily: "Rubik, sans-serif",
                fontSize: 14,
                fontWeight: 800,
                color: "rgba(255,255,255,0.3)",
              }}
            >
              VS
            </div>
            {/* Win probability arc */}
            <div className="relative">
              <svg width="90" height="50" viewBox="0 0 90 50">
                {/* Track */}
                <path d="M 10 45 A 35 35 0 0 1 80 45" stroke="rgba(255,255,255,0.08)" strokeWidth="6" fill="none" strokeLinecap="round" />
                {/* Team1 arc */}
                <path
                  d="M 10 45 A 35 35 0 0 1 80 45"
                  stroke="#00b8db"
                  strokeWidth="6"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={`${(game.rotobotPick === team1.id ? game.rotobotConfidence : 100 - game.rotobotConfidence) * 1.1} 200`}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center pb-2">
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", letterSpacing: "0.5px" }}>
                  AI
                </span>
              </div>
            </div>
          </div>

          <TeamHeader
            team={team2}
            isPick={game.rotobotPick === team2.id}
            confidence={100 - game.rotobotConfidence}
            side="right"
          />
        </div>

        {/* View mode toggle */}
        <div className="flex gap-1 p-1 rounded-xl mb-5 w-fit" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}>
          {[
            { id: "quick", label: "Quick Analysis", icon: Zap },
            { id: "deep", label: "Deep Dive", icon: BarChart2 },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setViewMode(id as typeof viewMode)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all"
              style={{
                fontFamily: "Rubik, sans-serif",
                fontSize: 13,
                fontWeight: viewMode === id ? 600 : 400,
                color: viewMode === id ? "white" : "rgba(255,255,255,0.4)",
                background: viewMode === id ? "rgba(0,184,219,0.15)" : "transparent",
                border: viewMode === id ? "1px solid rgba(0,184,219,0.3)" : "1px solid transparent",
                cursor: "pointer",
              }}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Left column */}
          <div className="md:col-span-2 flex flex-col gap-4">
            {/* RotoBot Analysis */}
            <div
              className="rounded-2xl p-5"
              style={{ background: "rgba(0,184,219,0.05)", border: "1px solid rgba(0,184,219,0.15)" }}
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "rgba(0,184,219,0.15)" }}>
                  <Brain size={14} color="#00b8db" />
                </div>
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, fontWeight: 700, color: "white" }}>
                  RotoBot Analysis
                </span>
                <div className="ml-auto flex items-center gap-1.5">
                  <Target size={11} color="#00b8db" />
                  <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, fontWeight: 700, color: "#00b8db" }}>
                    {game.rotobotConfidence}% {rotobotTeam.shortName}
                  </span>
                </div>
              </div>
              <p style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, color: "rgba(255,255,255,0.75)", lineHeight: 1.6 }}>
                {game.analysis}
              </p>
            </div>

            {/* Pros / Cons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Team 1 pros */}
              <div className="rounded-2xl p-4" style={{ background: "rgba(0,184,219,0.04)", border: "1px solid rgba(0,184,219,0.12)" }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full" style={{ background: "#00b8db" }} />
                  <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 700, color: "#00b8db" }}>
                    {team1.shortName} Advantages
                  </span>
                </div>
                <div className="flex flex-col gap-2">
                  {game.proTeam1.map((pro, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <TrendingUp size={12} color="#22c55e" className="mt-0.5 shrink-0" />
                      <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.65)", lineHeight: 1.4 }}>
                        {pro}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Team 2 pros */}
              <div className="rounded-2xl p-4" style={{ background: "rgba(60,132,255,0.04)", border: "1px solid rgba(60,132,255,0.12)" }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full" style={{ background: "#3c84ff" }} />
                  <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 700, color: "#3c84ff" }}>
                    {team2.shortName} Advantages
                  </span>
                </div>
                <div className="flex flex-col gap-2">
                  {game.proTeam2.map((pro, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <TrendingUp size={12} color="#22c55e" className="mt-0.5 shrink-0" />
                      <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.65)", lineHeight: 1.4 }}>
                        {pro}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Deep dive stats */}
            {viewMode === "deep" && (
              <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
                <div className="flex items-center justify-between mb-4">
                  <h3 style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, fontWeight: 700, color: "white" }}>
                    Statistical Comparison
                  </h3>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{ background: "#00b8db" }} />
                      <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{team1.shortName}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{ background: "#3c84ff" }} />
                      <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>{team2.shortName}</span>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-4">
                  <StatBar label="Points Per Game" val1={team1.ppg} val2={team2.ppg} />
                  <StatBar label="Opp Points Per Game" val1={team1.oppg} val2={team2.oppg} higherIsBetter={false} />
                  <StatBar label="eFG%" val1={team1.eFGPct} val2={team2.eFGPct} />
                  <StatBar label="Pace" val1={team1.pace} val2={team2.pace} />
                  <StatBar label="TOV%" val1={team1.tovPct} val2={team2.tovPct} higherIsBetter={false} />
                  <StatBar label="OREB%" val1={team1.orebPct} val2={team2.orebPct} />
                  <StatBar label="NET Rank" val1={team2.netRank} val2={team1.netRank} />
                </div>
              </div>
            )}

            {/* Radar chart (deep mode) */}
            {viewMode === "deep" && (
              <div className="rounded-2xl p-5" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
                <h3 style={{ fontFamily: "Rubik, sans-serif", fontSize: 14, fontWeight: 700, color: "white", marginBottom: 16 }}>
                  Team Radar
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="rgba(255,255,255,0.08)" />
                    <PolarAngleAxis
                      dataKey="subject"
                      tick={{ fontFamily: "Rubik, sans-serif", fontSize: 10, fill: "rgba(255,255,255,0.4)" }}
                    />
                    <Radar name={team1.shortName} dataKey="A" stroke="#00b8db" fill="#00b8db" fillOpacity={0.15} />
                    <Radar name={team2.shortName} dataKey="B" stroke="#3c84ff" fill="#3c84ff" fillOpacity={0.1} />
                    <Tooltip
                      contentStyle={{
                        background: "#0a0f1d",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: 8,
                        fontFamily: "Rubik, sans-serif",
                        fontSize: 12,
                        color: "white",
                      }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Right column */}
          <div className="flex flex-col gap-4">
            {/* Recent form */}
            <div className="rounded-2xl p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
              <h3 style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12, textTransform: "uppercase" as const, letterSpacing: "0.5px" }}>
                Recent Form (Last 5)
              </h3>
              <div className="flex flex-col gap-3">
                {[team1, team2].map((team, idx) => (
                  <div key={team.id}>
                    <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 6 }}>
                      {team.shortName}
                    </div>
                    <div className="flex gap-1.5">
                      {team.recentForm.map((r, i) => (
                        <FormBadge key={i} result={r} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Key players */}
            <div className="rounded-2xl p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
              <h3 style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12, textTransform: "uppercase" as const, letterSpacing: "0.5px" }}>
                Key Players
              </h3>
              <div className="flex flex-col gap-3">
                {[team1, team2].map((team, idx) => (
                  <div key={team.id} className="flex items-center gap-3">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                      style={{ background: `${team.color}22`, border: `1px solid ${team.color}44` }}
                    >
                      <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 9, fontWeight: 800, color: "white" }}>
                        {team.shortName.slice(0, 2).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, fontWeight: 600, color: "white" }}>
                        {team.keyPlayer}
                      </div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: idx === 0 ? "#00b8db" : "#3c84ff" }}>
                        {team.keyPlayerStat}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* RotoBot score comparison */}
            <div className="rounded-2xl p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
              <h3 style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.6)", marginBottom: 12, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                RotoBot Score
              </h3>
              {[team1, team2].map((team, idx) => (
                <div key={team.id} className="mb-3">
                  <div className="flex items-center justify-between mb-1.5">
                    <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
                      {team.shortName}
                    </span>
                    <span style={{
                      fontFamily: "Rubik, sans-serif",
                      fontSize: 14,
                      fontWeight: 700,
                      color: team.rotobotScore >= 80 ? "#00b8db" : team.rotobotScore >= 60 ? "#3c84ff" : team.rotobotScore >= 40 ? "#f59e0b" : "#ef4444",
                    }}>
                      {team.rotobotScore}
                    </span>
                  </div>
                  <div className="h-2 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${team.rotobotScore}%`,
                        background: idx === 0
                          ? "linear-gradient(90deg, #00b8db, #22c55e)"
                          : "linear-gradient(90deg, #3c84ff, #8b5cf6)",
                      }}
                    />
                  </div>
                </div>
              ))}
              <p style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.3)", lineHeight: 1.4, marginTop: 8 }}>
                Composite score based on offense, defense, pace, schedule strength, and recent form.
              </p>
            </div>

            {/* Make your pick */}
            <div className="rounded-2xl p-4" style={{ background: "rgba(0,184,219,0.05)", border: "1px solid rgba(0,184,219,0.2)" }}>
              <h3 style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, fontWeight: 700, color: "white", marginBottom: 12 }}>
                Make Your Pick
              </h3>
              <div className="flex flex-col gap-2">
                {[team1, team2].map((team) => (
                  <button
                    key={team.id}
                    onClick={() => setUserPick(team.id)}
                    className="flex items-center gap-3 px-3 py-3 rounded-xl w-full transition-all"
                    style={{
                      background: userPick === team.id ? "rgba(0,184,219,0.15)" : "rgba(255,255,255,0.03)",
                      border: `1px solid ${userPick === team.id ? "rgba(0,184,219,0.4)" : "rgba(255,255,255,0.08)"}`,
                      cursor: "pointer",
                    }}
                  >
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center shrink-0"
                      style={{
                        background: userPick === team.id ? "#00b8db" : "rgba(255,255,255,0.08)",
                        border: `2px solid ${userPick === team.id ? "#00b8db" : "rgba(255,255,255,0.15)"}`,
                      }}
                    >
                      {userPick === team.id && <CheckCircle2 size={14} color="white" />}
                    </div>
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ background: `${team.color}22` }}
                    >
                      <span style={{ fontSize: 9, fontWeight: 800, color: "white" }}>{team.shortName.slice(0, 2).toUpperCase()}</span>
                    </div>
                    <div className="text-left flex-1">
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, fontWeight: 600, color: "white" }}>
                        {team.shortName}
                      </div>
                      <div style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "rgba(255,255,255,0.35)" }}>
                        #{team.seed} Seed
                      </div>
                    </div>
                    {game.rotobotPick === team.id && (
                      <div className="flex items-center gap-1">
                        <Brain size={10} color="#00b8db" />
                        <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 9, color: "#00b8db" }}>AI</span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
              {userPick && (
                <Link
                  to="/bracket"
                  className="no-underline w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl mt-3 transition-all hover:opacity-90"
                  style={{
                    background: "linear-gradient(135deg, #00b8db, #3c84ff)",
                    fontFamily: "Rubik, sans-serif",
                    fontSize: 13,
                    fontWeight: 600,
                    color: "white",
                  }}
                >
                  <CheckCircle2 size={14} />
                  Confirm Pick & Continue
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}