import { useState } from "react";
import { Download, Brain, Eye, Share2, CheckCircle } from "lucide-react";
import { BracketGameCard, BracketConnector } from "./BracketGame";
import {
  EAST_R1_GAMES,
  WEST_R1_GAMES,
  SOUTH_TEAMS,
  MIDWEST_TEAMS,
  type Game,
  type Team,
} from "../data/bracketData";

// Build South R1 games from teams
function buildGames(teams: Team[], region: string): Game[] {
  const pairs = [[0,1],[2,3],[4,5],[6,7],[8,9],[10,11],[12,13],[14,15]];
  return pairs.map((pair, i) => {
    const t1 = teams[pair[0]];
    const t2 = teams[pair[1]];
    const diff = t1.rotobotScore - t2.rotobotScore;
    const pick = t1.rotobotScore > t2.rotobotScore ? t1.id : t2.id;
    const confidence = Math.min(98, Math.max(51, 50 + Math.abs(diff) * 2.5));
    return {
      id: `${region.toLowerCase()}-r1-${i+1}`,
      round: 1,
      region,
      team1: t1,
      team2: t2,
      rotobotPick: pick,
      rotobotConfidence: Math.round(confidence),
      location: "TBD",
      analysis: `${t1.shortName} vs ${t2.shortName}: ${t1.rotobotBlurb}`,
      proTeam1: [t1.rotobotBlurb],
      proTeam2: [t2.rotobotBlurb],
    };
  });
}

const SOUTH_R1_GAMES = buildGames(SOUTH_TEAMS, "South");
const MIDWEST_R1_GAMES = buildGames(MIDWEST_TEAMS, "Midwest");

const REGION_GAMES: Record<string, Game[]> = {
  East: EAST_R1_GAMES,
  West: WEST_R1_GAMES,
  South: SOUTH_R1_GAMES,
  Midwest: MIDWEST_R1_GAMES,
};

// Mock R2, S16, E8 games built from R1 rotobot picks
function buildLaterRounds(r1Games: Game[], region: string): { r2: Game[]; s16: Game[]; e8: Game[] } {
  const getTeamById = (id: string, games: Game[]): Team => {
    for (const g of games) {
      if (g.team1.id === id) return g.team1;
      if (g.team2.id === id) return g.team2;
    }
    return games[0].team1;
  };

  const makeGame = (t1: Team, t2: Team, round: number, idx: number): Game => {
    const diff = t1.rotobotScore - t2.rotobotScore;
    const pick = t1.rotobotScore > t2.rotobotScore ? t1.id : t2.id;
    const confidence = Math.min(92, Math.max(52, 50 + Math.abs(diff) * 2.2));
    return {
      id: `${region.toLowerCase()}-r${round}-${idx+1}`,
      round,
      region,
      team1: t1,
      team2: t2,
      rotobotPick: pick,
      rotobotConfidence: Math.round(confidence),
      location: "TBD",
      analysis: `RotoBot's projected R${round} matchup`,
      proTeam1: [t1.rotobotBlurb],
      proTeam2: [t2.rotobotBlurb],
    };
  };

  const r1Picks = r1Games.map(g =>
    g.rotobotPick === g.team1.id ? g.team1 : g.team2
  );

  const r2Games: Game[] = [];
  for (let i = 0; i < r1Picks.length; i += 2) {
    r2Games.push(makeGame(r1Picks[i], r1Picks[i + 1], 2, i / 2));
  }
  const r2Picks = r2Games.map(g =>
    g.rotobotPick === g.team1.id ? g.team1 : g.team2
  );

  const s16Games: Game[] = [];
  for (let i = 0; i < r2Picks.length; i += 2) {
    s16Games.push(makeGame(r2Picks[i], r2Picks[i + 1], 3, i / 2));
  }
  const s16Picks = s16Games.map(g =>
    g.rotobotPick === g.team1.id ? g.team1 : g.team2
  );

  const e8Games: Game[] = [makeGame(s16Picks[0], s16Picks[1], 4, 0)];

  return { r2: r2Games, s16: s16Games, e8: e8Games };
}

interface RoundColumnProps {
  games: Game[];
  label: string;
  userPicks: Record<string, string>;
  onPick: (gameId: string, teamId: string) => void;
  totalHeight: number;
}

function RoundColumn({ games, label, userPicks, onPick, totalHeight }: RoundColumnProps) {
  return (
    <div className="flex flex-col" style={{ height: totalHeight, width: 210 }}>
      <div className="text-center pb-2">
        <span style={{
          fontFamily: "Rubik, sans-serif",
          fontSize: 10,
          fontWeight: 700,
          color: "rgba(255,255,255,0.3)",
          textTransform: "uppercase",
          letterSpacing: "1px"
        }}>
          {label}
        </span>
      </div>
      <div className="flex flex-col flex-1" style={{ justifyContent: "space-around", gap: 0 }}>
        {games.map((game) => (
          <div key={game.id} className="flex items-center justify-center">
            <BracketGameCard
              game={game}
              userPick={userPicks[game.id]}
              onPick={onPick}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function ConnectorColumn({ fromCount, totalHeight }: { fromCount: number; totalHeight: number }) {
  return (
    <div style={{ height: totalHeight, paddingTop: 24 }}>
      <BracketConnector count={fromCount} height={totalHeight - 24} />
    </div>
  );
}

function RegionBracket({
  region,
  r1Games,
  userPicks,
  onPick,
}: {
  region: string;
  r1Games: Game[];
  userPicks: Record<string, string>;
  onPick: (gameId: string, teamId: string) => void;
}) {
  const { r2, s16, e8 } = buildLaterRounds(r1Games, region);
  const BRACKET_H = 780;

  return (
    <div className="overflow-x-auto pb-4">
      <div style={{ display: "flex", gap: 0, alignItems: "stretch", minWidth: 1000, paddingBottom: 8 }}>
        {/* Round 1 */}
        <RoundColumn games={r1Games} label="First Round (R64)" userPicks={userPicks} onPick={onPick} totalHeight={BRACKET_H} />
        <ConnectorColumn fromCount={8} totalHeight={BRACKET_H} />

        {/* Round 2 */}
        <RoundColumn games={r2} label="Second Round" userPicks={userPicks} onPick={onPick} totalHeight={BRACKET_H} />
        <ConnectorColumn fromCount={4} totalHeight={BRACKET_H} />

        {/* Sweet 16 */}
        <RoundColumn games={s16} label="Sweet 16" userPicks={userPicks} onPick={onPick} totalHeight={BRACKET_H} />
        <ConnectorColumn fromCount={2} totalHeight={BRACKET_H} />

        {/* Elite 8 */}
        <div className="flex flex-col" style={{ height: BRACKET_H, width: 210 }}>
          <div className="text-center pb-2">
            <span style={{
              fontFamily: "Rubik, sans-serif", fontSize: 10, fontWeight: 700,
              color: "#00b8db", textTransform: "uppercase", letterSpacing: "1px"
            }}>
              Elite 8 🏆
            </span>
          </div>
          <div className="flex flex-col flex-1 items-center justify-center">
            <BracketGameCard
              game={e8[0]}
              userPick={userPicks[e8[0].id]}
              onPick={onPick}
            />
            <div className="mt-3 px-3 py-2 rounded-xl" style={{
              background: "rgba(0,184,219,0.08)",
              border: "1px solid rgba(0,184,219,0.2)",
              maxWidth: 210,
            }}>
              <div className="flex items-center gap-1.5 mb-1">
                <Brain size={10} color="#00b8db" />
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 10, color: "#00b8db", fontWeight: 600 }}>
                  Regional Champion
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div
                  className="w-6 h-6 rounded shrink-0"
                  style={{
                    background: `${e8[0].rotobotPick === e8[0].team1.id ? e8[0].team1.color : e8[0].team2.color}33`
                  }}
                />
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, fontWeight: 700, color: "white" }}>
                  {e8[0].rotobotPick === e8[0].team1.id ? e8[0].team1.shortName : e8[0].team2.shortName}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const REGIONS = ["East", "West", "South", "Midwest"];
const REGION_COLORS: Record<string, string> = {
  East: "#00b8db",
  West: "#3c84ff",
  South: "#22c55e",
  Midwest: "#f59e0b",
};

export function BracketScreen() {
  const [activeRegion, setActiveRegion] = useState("East");
  const [viewMode, setViewMode] = useState<"user" | "rotobot" | "both">("both");
  const [userPicks, setUserPicks] = useState<Record<string, string>>({});

  const r1Games = REGION_GAMES[activeRegion];
  const pickedCount = Object.keys(userPicks).length;
  const totalGames = 63;
  const progress = Math.round((pickedCount / totalGames) * 100);

  const handlePick = (gameId: string, teamId: string) => {
    setUserPicks(prev => ({ ...prev, [gameId]: teamId }));
  };

  return (
    <div
      className="min-h-screen pt-16 pb-20 md:pb-8"
      style={{ background: "linear-gradient(160deg, #010c2a 0%, #030712 40%, #00081e 100%)" }}
    >
      {/* Background glow */}
      <div
        className="fixed pointer-events-none"
        style={{
          top: "10%", right: "0%", width: 500, height: 500,
          background: "radial-gradient(ellipse, rgba(60,132,255,0.07) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 relative">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h1 style={{ fontFamily: "Rubik, sans-serif", fontSize: 24, fontWeight: 800, color: "white", margin: 0 }}>
                2026 NCAA Tournament Bracket
              </h1>
              <div
                className="px-2 py-0.5 rounded-full"
                style={{
                  background: "rgba(245,158,11,0.15)",
                  border: "1px solid rgba(245,158,11,0.3)",
                  fontFamily: "Rubik, sans-serif",
                  fontSize: 10,
                  fontWeight: 700,
                  color: "#f59e0b",
                  textTransform: "uppercase",
                  letterSpacing: "0.5px",
                }}
              >
                Preview Mode
              </div>
            </div>
            <p style={{ fontFamily: "Rubik, sans-serif", fontSize: 13, color: "rgba(255,255,255,0.4)" }}>
              Bracket seeds not yet official. Projections based on 2025–26 season data.
            </p>
          </div>

          {/* Progress */}
          <div
            className="flex items-center gap-4 px-4 py-3 rounded-xl"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <div className="flex flex-col gap-1">
              <div className="flex items-center justify-between gap-6">
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
                  Bracket Progress
                </span>
                <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, fontWeight: 700, color: "#00b8db" }}>
                  {pickedCount}/{totalGames}
                </span>
              </div>
              <div className="h-1.5 w-40 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${progress}%`,
                    background: "linear-gradient(90deg, #00b8db, #3c84ff)",
                  }}
                />
              </div>
            </div>
            <button
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all hover:opacity-80"
              style={{
                background: "linear-gradient(135deg, #00b8db, #3c84ff)",
                fontFamily: "Rubik, sans-serif",
                fontSize: 12,
                fontWeight: 600,
                color: "white",
                border: "none",
                cursor: "pointer",
              }}
            >
              <Download size={13} />
              Save
            </button>
          </div>
        </div>

        {/* Controls row */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          {/* Region tabs */}
          <div
            className="flex gap-1 p-1 rounded-xl"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
          >
            {REGIONS.map(region => (
              <button
                key={region}
                onClick={() => setActiveRegion(region)}
                className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all"
                style={{
                  fontFamily: "Rubik, sans-serif",
                  fontSize: 13,
                  fontWeight: activeRegion === region ? 700 : 400,
                  color: activeRegion === region ? "white" : "rgba(255,255,255,0.45)",
                  background: activeRegion === region ? `${REGION_COLORS[region]}22` : "transparent",
                  border: activeRegion === region ? `1px solid ${REGION_COLORS[region]}44` : "1px solid transparent",
                  cursor: "pointer",
                }}
              >
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: REGION_COLORS[region], opacity: activeRegion === region ? 1 : 0.3 }}
                />
                {region}
              </button>
            ))}
          </div>

          {/* View mode */}
          <div
            className="flex gap-1 p-1 rounded-xl ml-auto"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
          >
            {[
              { id: "rotobot", label: "RotoBot Picks", icon: Brain },
              { id: "user", label: "My Picks", icon: CheckCircle },
              { id: "both", label: "Both", icon: Eye },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setViewMode(id as typeof viewMode)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all"
                style={{
                  fontFamily: "Rubik, sans-serif",
                  fontSize: 12,
                  fontWeight: viewMode === id ? 600 : 400,
                  color: viewMode === id ? "white" : "rgba(255,255,255,0.4)",
                  background: viewMode === id ? "rgba(255,255,255,0.1)" : "transparent",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <Icon size={12} />
                <span className="hidden sm:block">{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Region header */}
        <div
          className="flex items-center gap-3 mb-5 px-4 py-3 rounded-xl"
          style={{
            background: `${REGION_COLORS[activeRegion]}08`,
            border: `1px solid ${REGION_COLORS[activeRegion]}20`,
          }}
        >
          <div className="w-2 h-2 rounded-full" style={{ background: REGION_COLORS[activeRegion] }} />
          <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 15, fontWeight: 700, color: "white" }}>
            {activeRegion} Region
          </span>
          <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 12, color: "rgba(255,255,255,0.35)" }}>
            — Click a team to make your pick • Click any game for AI analysis
          </span>
          <div className="ml-auto flex items-center gap-2">
            <Brain size={12} color="#00b8db" />
            <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "#00b8db" }}>
              RotoBot highlights favorites
            </span>
          </div>
        </div>

        {/* Bracket */}
        <div
          className="rounded-2xl p-4 overflow-hidden"
          style={{
            background: "rgba(255,255,255,0.02)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <RegionBracket
            region={activeRegion}
            r1Games={r1Games}
            userPicks={userPicks}
            onPick={handlePick}
          />
        </div>

        {/* Legend + actions */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Brain size={11} color="#00b8db" />
              <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
                RotoBot's pick
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full" style={{ background: "#22c55e" }} />
              <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
                Your pick
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-0.5 w-6 rounded-full" style={{ background: "rgba(0,184,219,0.6)" }} />
              <span style={{ fontFamily: "Rubik, sans-serif", fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
                Advancing
              </span>
            </div>
          </div>
          <div className="ml-auto flex gap-2">
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:opacity-80"
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                fontFamily: "Rubik, sans-serif",
                fontSize: 12,
                fontWeight: 500,
                color: "rgba(255,255,255,0.7)",
                cursor: "pointer",
              }}
            >
              <Share2 size={13} />
              Share
            </button>
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-xl transition-all hover:opacity-80"
              style={{
                background: "linear-gradient(135deg, #00b8db, #3c84ff)",
                fontFamily: "Rubik, sans-serif",
                fontSize: 12,
                fontWeight: 600,
                color: "white",
                border: "none",
                cursor: "pointer",
              }}
            >
              <Download size={13} />
              Export as Image
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
